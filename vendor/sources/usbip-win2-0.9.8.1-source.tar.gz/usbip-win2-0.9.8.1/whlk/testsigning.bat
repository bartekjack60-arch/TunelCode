bcdedit /set testsigning on
