/*
 * Copyright (c) 2022-2026 Vadym Hrynchyshyn <vadimgrn@gmail.com>
 */

#pragma once

#include "../dllspec.h"

#include <string>
#include <string_view>
#include <vector>
#include <expected>
#include <optional>

namespace usbip
{

/**
 * Trims trailing characters (by default whitespace: space, tab, CR, LF).
 */
USBIP_API std::wstring_view trim_right(_In_ std::wstring_view s, _In_ std::wstring_view chars = L" \t\r\n") noexcept;
USBIP_API std::string_view  trim_right(_In_ std::string_view s,  _In_ std::string_view chars = " \t\r\n") noexcept;

USBIP_API std::wstring& trim_right(_Inout_ std::wstring &s, _In_ std::wstring_view chars = L" \t\r\n");
USBIP_API std::string&  trim_right(_Inout_ std::string &s,  _In_ std::string_view chars = " \t\r\n");


/**
 * @return value or result of GetLastError()
 */
USBIP_API std::expected<std::wstring, unsigned long> utf8_to_wchar(_In_ std::string_view s);
USBIP_API std::expected<std::string,  unsigned long> wchar_to_utf8(_In_ std::wstring_view ws);

USBIP_API std::wstring utf8_to_wchar_or(_In_ std::string_view s, _In_ std::optional<std::wstring_view> val = std::nullopt);
USBIP_API std::string  wchar_to_utf8_or(_In_ std::wstring_view ws, _In_ std::optional<std::string_view> val = std::nullopt);

/**
 * Empty strings or strings beginning with L'\0' will be skipped.
 * If string has L'\0', characters after it will not be included.
 * @return multi-sz string
 * Examples: 
 * {"aaa\0\zzz", "\0", "bbb", ""} -> "aaa\0\bbb\0\0"
 * {} -> "\0\0"
 */
USBIP_API std::wstring make_multi_sz(_In_ const std::vector<std::wstring> &v);

/**
 * @param str list of strings, each ending with L'\0'.
 *            Extra '\0' at end terminates the list.
 *            Split stops if head begins with L'\0'.
 * @return vector of strings that does not contain empty strings
 *
 * Examples:
 * "aaa\0\bbb\0\0" -> {"aaa", "bbb"}
 * "aaa\0\bbb\0\0\ccc" -> {"aaa", "bbb"}
 * "\0aaa\0\bbb\0\0" -> {}
 */
USBIP_API std::vector<std::wstring> split_multi_sz(_In_ std::wstring_view str);

} // namespace usbip
