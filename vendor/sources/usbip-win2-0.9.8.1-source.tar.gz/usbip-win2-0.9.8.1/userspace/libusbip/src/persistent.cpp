/*
 * Copyright (c) 2023-2026 Vadym Hrynchyshyn <vadimgrn@gmail.com>
 */

#include "../persistent.h"
#include "../vhci.h"
#include "output.h"

#include <usbip/vhci.h>

#include <charconv>
#include <ranges>
#include <span>

namespace
{

using namespace usbip;

auto is_malformed(_In_ const device_location &d) noexcept
{
        return d.hostname.empty() || d.service.empty() || d.busid.empty();
}

auto is_malformed(_In_ const persistent_device &d) noexcept
{
        return is_malformed(d.location) || !validate_device_serial(d.serial);
}

std::expected<std::wstring, DWORD> devices_to_multi_sz(_In_ const std::vector<persistent_device> &devices)
{
        std::wstring multi_sz;

        for (auto &d: devices) {
                auto &dl = d.location;
                auto wsk_events = d.recv_mode == receive_mode::low_latency;

                if (is_malformed(d)) {
                        libusbip::output("malformed persistent_device( hostname='{}', service='{}', "
                                         "busid='{}', serial='{}', wsk_events={}, once={} )",
                                         dl.hostname, dl.service, dl.busid, d.serial, wsk_events, d.once);

                        return std::unexpected(ERROR_INVALID_PARAMETER);
                }

                auto flags = pack_attach_flags(d.once, wsk_events);

                if (auto s = std::format("{},{},{},{},{}", dl.hostname, dl.service, dl.busid, d.serial, flags);
                    auto ws = utf8_to_wchar(s)) {
                        *ws += L'\0';
                        multi_sz += *ws;
                } else {
                        libusbip::output("utf8_to_wchar('{}') error {}", s, ws.error());
                        return std::unexpected(ERROR_INVALID_PARAMETER);
                }
        }

        multi_sz += L'\0';
        if (devices.empty()) { // double null terminator if empty
                multi_sz += L'\0';
        }

        return multi_sz;
}

/*
 * Format: hostname,service,busid,serial[,flags[,...]]
 * Designed for forward and backward compatibility:
 * - Backward compatibility: older entries with fewer fields (e.g. omitting flags)
 *   retain default values; is_malformed() validates that required fields are present.
 * - Forward compatibility: future entries with extra trailing comma-separated fields
 *   are accepted; only known fields are parsed and remaining tokens are ignored.
 */
auto parse_persistent_device(_In_ const std::string &str)
{
        std::optional<persistent_device> result(std::in_place);

        auto &dev = *result;
        auto &loc = dev.location;

        auto v = str | std::views::split(',');
        auto it = v.begin();

        if (it != v.end()) {
                loc.hostname = std::string_view(*it++);
        }

        if (it != v.end()) {
                loc.service = std::string_view(*it++);
        }

        if (it != v.end()) {
                loc.busid = std::string_view(*it++);
        }

        if (it != v.end()) {
                dev.serial = std::string_view(*it++);
        }

        if (it != v.end()) {
                std::string_view s(*it++);

                ULONG flags{};
                auto [end, ec] = std::from_chars(s.data(), s.data() + s.size(), flags);

                if (ec == std::errc{} && end == s.data() + s.size()) {
                        bool wsk_events;
                        unpack_attach_flags(dev.once, wsk_events, flags);

                        dev.recv_mode = wsk_events ? receive_mode::low_latency : receive_mode::zero_copy;
                } else {
                        result.reset();
                }
        }

        return result;
}

auto get_persistent_devices(_In_ HANDLE dev)
{
        std::optional<std::wstring> val(std::in_place, 512, L'\0');
        constexpr int max_attempts = 3;

        for (int attempt = 0; attempt < max_attempts; ++attempt) {

                auto bytes = std::span(*val).size_bytes();

                DWORD BytesReturned{}; // must be set if the last arg is NULL
                auto ok = DeviceIoControl(dev, vhci::ioctl::GET_PERSISTENT, nullptr, 0, 
                                          val->data(), static_cast<DWORD>(bytes), &BytesReturned, nullptr);

                auto cnt = BytesReturned/sizeof(val->front());

                if (ok) {
                        val->resize(cnt);
                        return val;
                }

                if (GetLastError() == ERROR_MORE_DATA && BytesReturned > bytes) { // WdfRegistryQueryValue -> STATUS_BUFFER_OVERFLOW
                        val->resize(cnt);
                } else {
                        break;
                }
        }

        val.reset();
        return val;
}

} // namespace


bool usbip::vhci::set_persistent(_In_ HANDLE dev, _In_ const std::vector<persistent_device> &devices)
{
        auto val = devices_to_multi_sz(devices);
        if (!val) {
                SetLastError(val.error());
                return false;
        }

        auto bytes = std::span(*val).size_bytes();
        DWORD BytesReturned{}; // must be set if the last arg is NULL

        auto ok = DeviceIoControl(dev, ioctl::SET_PERSISTENT, val->data(), static_cast<DWORD>(bytes),
                                  nullptr, 0, &BytesReturned, nullptr);

        assert(!BytesReturned);
        return ok;
}

auto usbip::vhci::get_persistent(_In_ HANDLE dev) -> std::optional<std::vector<persistent_device>>
{
        std::optional<std::vector<persistent_device>> devs;

        auto multi_sz = get_persistent_devices(dev);
        if (!multi_sz) {
                if (GetLastError() == ERROR_FILE_NOT_FOUND) { // persistent_devices_value_name is absent
                        devs.emplace(); // not an error
                }
                return devs;
        }

        auto strings = split_multi_sz(*multi_sz);

        devs.emplace();
        devs->reserve(strings.size());

        for (auto &ws: strings) {
                if (auto s = wchar_to_utf8(ws); !s) {
                        libusbip::output("wchar_to_utf8 error {}", s.error());
                } else if (auto d = parse_persistent_device(*s); d && !is_malformed(*d)) {
                        devs->push_back(std::move(*d));
                } else {
                        libusbip::output("invalid '{}'", *s);
                }
        }

        return devs;
}
