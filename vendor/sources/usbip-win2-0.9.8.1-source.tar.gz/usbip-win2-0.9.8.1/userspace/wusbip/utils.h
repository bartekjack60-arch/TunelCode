/*
 * Copyright (c) 2023-2026 Vadym Hrynchyshyn <vadimgrn@gmail.com>
 */

#pragma once

#include <libusbip/vhci.h>

#include <string_view>
#include <tuple>
#include <optional>

#include <wx/string.h>

namespace win
{

class FileVersion;
const FileVersion& get_file_version();

} // namespace win


namespace usbip
{

bool init(_Inout_ wxString &err);

wxString get_last_error_msg(_In_ DWORD msg_id = GetLastError());
Handle& get_vhci();

class UsbIds;
const UsbIds& get_ids();


const wchar_t* get_speed_str(_In_ USB_DEVICE_SPEED speed) noexcept;
std::optional<USB_DEVICE_SPEED> get_speed_val(_In_ const wxString &speed) noexcept;

wxString to_string(_In_ state state);

struct usb_device;
imported_device make_imported_device(_In_ std::string hostname, _In_ std::string service, _In_ const usb_device &dev);

wxString make_device_url(_In_ const device_location &loc);

wxString make_server_url(_In_ const device_location &loc);
wxString make_server_url(_In_ const wxString &hostname, _In_ const wxString &service);

bool split_server_url(_In_ const wxString &url, _Inout_ wxString &hostname, _Inout_ wxString &service);

constexpr UINT32 make_devid(_In_ int busnum, _In_ int devnum) noexcept
{
        return (busnum << 16) | (devnum & USHRT_MAX);
}

inline auto wstring_view(_In_ const wxString &s) noexcept
{
        return std::wstring_view(s.wx_str(), s.length());
}

inline auto wx_string(_In_ std::wstring_view s)
{
        return wxString(s.data(), s.length());
}

constexpr auto get_cmp_key(_In_ const device_location &d)
{
        return std::tie(d.hostname, d.service, d.busid); // tuple of lvalue references
}

constexpr auto operator == (_In_ const device_location &a, _In_ const device_location &b)
{
        return get_cmp_key(a) == get_cmp_key(b);
}

constexpr auto operator <=> (_In_ const device_location &a, _In_ const device_location &b)
{
        return get_cmp_key(a) <=> get_cmp_key(b);
}

constexpr auto operator == (_In_ const persistent_device &a, _In_ const persistent_device &b)
{
        return a.location == b.location; // ignore serial
}

constexpr auto operator <=> (_In_ const persistent_device &a, _In_ const persistent_device &b)
{
        return a.location <=> b.location; // ignore serial
}

constexpr auto isdigit(_In_ wchar_t ch) noexcept
{
        return ch <= L'9' && ch >= L'0';
}

} // namespace usbip
