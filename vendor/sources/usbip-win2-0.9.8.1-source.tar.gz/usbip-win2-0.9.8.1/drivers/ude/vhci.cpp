/*
 * Copyright (c) 2022-2026 Vadym Hrynchyshyn <vadimgrn@gmail.com>
 */

#include "vhci.h"
#include "trace.h"
#include "vhci.tmh"

#include "driver.h"
#include "device.h"
#include "vhci_ioctl.h"
#include "persistent.h"

#include <libdrv/wdm_cpp.h>
#include <libdrv/utils.h>

#include <ntstrsafe.h>
#include <usbiodef.h>

extern "C" {
#include <usbdlib.h>
}

namespace
{

using namespace usbip;
using namespace libdrv;

/*
 * WDF calls the callback at PASSIVE_LEVEL if object's handle type is WDFDEVICE.
 */
_Function_class_(EVT_WDF_DEVICE_CONTEXT_CLEANUP)
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
PAGED void vhci_cleanup(_In_ WDFOBJECT object)
{
        PAGED_CODE();
        TraceDbg("%04x", ptr04x(object));

        auto vhci = static_cast<WDFDEVICE>(object);
        auto &ctx = *get_vhci_ctx(vhci);

        set_flag(ctx.removing); // used to set earlier

        if (auto t = ctx.target_self) {
                WdfIoTargetClose(t);
        }

        unique_ptr{ctx.devices}; // destroy
        ctx.devices = nullptr;

        ctx.devices_cnt = 0;
        ctx.usb2_ports = 0;
}

_Function_class_(EVT_WDF_IO_QUEUE_IO_CANCELED_ON_QUEUE)
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
void NTAPI canceled_on_queue(_In_ WDFQUEUE, _In_ WDFREQUEST request)
{
        TraceDbg("read request %04x", ptr04x(request));
        WdfRequestComplete(request, STATUS_CANCELLED);
}

_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED auto create_read_queue(_Out_ WDFQUEUE &queue, _In_ WDF_OBJECT_ATTRIBUTES &attr, _In_ WDFDEVICE vhci)
{
        PAGED_CODE();

        WDF_IO_QUEUE_CONFIG cfg;
        WDF_IO_QUEUE_CONFIG_INIT(&cfg, WdfIoQueueDispatchManual);
        cfg.PowerManaged = WdfFalse;
        cfg.EvtIoCanceledOnQueue = canceled_on_queue;

        auto st = WdfIoQueueCreate(vhci, &cfg, &attr, &queue);

        if (NT_ERROR(st)) {
                Trace(TRACE_LEVEL_ERROR, "WdfIoQueueCreate %!STATUS!", st);
        } else {
                TraceDbg("vhci %04x, queue %04x", ptr04x(vhci), ptr04x(queue));
        }

        return st;
}

_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED auto query_usb_ports_cnt(_In_ int def_cnt)
{
        PAGED_CODE();

        struct {
                enum { usb3, usb2 };
                int cnt[2];
        } v {def_cnt, def_cnt};

        registry key;
        auto st = open(key, DriverRegKeyParameters);
        if (NT_ERROR(st)) {
                return v;
        }

        struct {
                UNICODE_STRING name;
                int &value;
        } const params[] = {
                { RTL_CONSTANT_STRING(L"NumberOfUsb20Ports"), v.cnt[v.usb2] },
                { RTL_CONSTANT_STRING(L"NumberOfUsb30Ports"), v.cnt[v.usb3] },
        };

        for (auto& [name, value]: params) {
                ULONG val{};
                st = WdfRegistryQueryULong(key.get(), &name, &val);

                if (NT_ERROR(st)) {
                        Trace(TRACE_LEVEL_VERBOSE, "WdfRegistryQueryULong(%!USTR!) %!STATUS!", &name, st);
                } else {
                        value = val;
                }
        }

        return v;
}

/*
 * Ports number cannot be zero and total ports number cannot exceed 255.
 * @see userspace/usbip/usbip.cpp, MAX_HUB_PORTS
 */
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED void set_usb_ports_cnt(_Inout_ int &usb2_ports, _Inout_ int &usb3_ports)
{
        PAGED_CODE();

        enum { MIN_PORTS = 1, DEF_PORTS = 30, MAX_PORTS = 254, MAX_TOTAL_PORTS };
        auto v = query_usb_ports_cnt(DEF_PORTS);

        for (int total = 0; auto &n: v.cnt) {

                n = min(MAX_PORTS, max(MIN_PORTS, n));

                if (total + n > MAX_TOTAL_PORTS) {
                        n = MAX_TOTAL_PORTS - total;
                }

                NT_ASSERT(n >= MIN_PORTS);
                NT_ASSERT(n <= MAX_PORTS);

                total += n;
                NT_ASSERT(total <= MAX_TOTAL_PORTS);
        }

        usb2_ports = v.cnt[v.usb2];
        usb3_ports = v.cnt[v.usb3];
}

_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED auto alloc_devices(_Inout_ vhci_ctx &vhci)
{
        PAGED_CODE();

        int usb2_ports{};
        int usb3_ports{};
        set_usb_ports_cnt(usb2_ports, usb3_ports);

        auto n = usb2_ports + usb3_ports;
        NT_ASSERT(n > 0);

        unique_ptr ptr(NonPagedPoolNx, n*sizeof(*vhci.devices));
        if (!ptr) {
                Trace(TRACE_LEVEL_ERROR, "Cannot allocate array UDECXUSBDEVICE[%d]", n);
                return STATUS_INSUFFICIENT_RESOURCES;
        }

        vhci.usb2_ports = usb2_ports;
        vhci.devices_cnt = n;
        vhci.devices = ptr.release<UDECXUSBDEVICE>();

        Trace(TRACE_LEVEL_INFORMATION, "usb2 ports %d, UDECXUSBDEVICE[%d]", vhci.usb2_ports, vhci.devices_cnt);
        return STATUS_SUCCESS;
}

_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED auto create_target_self(_Out_ WDFIOTARGET &target, _In_ WDF_OBJECT_ATTRIBUTES &attr, _In_ WDFDEVICE vhci)
{
        PAGED_CODE();

        auto st = WdfIoTargetCreate(vhci, &attr, &target);
        if (NT_ERROR(st)) {
                Trace(TRACE_LEVEL_ERROR, "WdfIoTargetCreate %!STATUS!", st);
                return st;
        }

        auto fdo = WdfDeviceWdmGetDeviceObject(vhci);

        WDF_IO_TARGET_OPEN_PARAMS params;
        WDF_IO_TARGET_OPEN_PARAMS_INIT_EXISTING_DEVICE(&params, fdo);

        st = WdfIoTargetOpen(target, &params);
        if (NT_ERROR(st)) {
                Trace(TRACE_LEVEL_ERROR, "WdfIoTargetOpen %!STATUS!", st);
        }
        return st;
}

/*
total = 0
max_total = 2*60*60 # two hours

delay = 30 # ReattachFirstDelay
max_delay = 8*60 # ReattachMaxDelay

for i in range(1000): # ReattachMaxAttempts
        total = total + delay
        if total > max_total:
            break
        
        hours = int(total/(60*60))

        mins = int((total - 60*60*hours)/60)
        assert mins < 60

        secs = total - 60*60*hours - 60*mins
        assert secs < 60

        print(f"{i}, delay={delay}s, total={total}s -> {hours}h, {mins}m, {secs}s")

        if delay != max_delay:
                delay = int(3*delay/2) # get_delay()
                if delay > max_delay:
                        delay = max_delay
 */
constexpr auto get_max_attach_attempts(
        unsigned int first_delay, unsigned int max_delay, unsigned int max_total_delay)
{
        auto cnt = 0U;

        for (auto delay = first_delay, total = 0U; ; ++cnt) {

                if (total += delay; total <= max_total_delay) {
                        delay = get_next_delay(delay, max_delay);
                } else {
                        break;
                }
        }

        return cnt;
}

/*
 * @see .inf, ReattachMaxAttempts, ReattachFirstDelay, ReattachMaxDelay
 */
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED void init_constants(
        _Inout_ unsigned int &max_attempts, _Inout_ unsigned int &first_delay, _Inout_ unsigned int &max_delay)
{
        PAGED_CODE();

        enum { // seconds
                HOUR = 60*60,
                DEF_FIRST_DELAY = 30, DEF_MAX_DELAY = 8*60, // see .inf
                DEF_MAX_ATTEMPTS = get_max_attach_attempts(DEF_FIRST_DELAY, DEF_MAX_DELAY, 2*HOUR), 
                MIN_DELAY = 1, MAX_DELAY = HOUR, MAX_TOTAL_DELAY = 72*HOUR
        };
        static_assert(DEF_MAX_ATTEMPTS == 20); // see.inf

        registry key; 
        if (NT_ERROR(open(key, DriverRegKeyParameters))) {
                max_attempts = DEF_MAX_ATTEMPTS;
                first_delay = DEF_FIRST_DELAY;
                max_delay = DEF_MAX_DELAY;
                return;
        }

        struct {
                UNICODE_STRING name;
                unsigned int &val;
        } const v[] {
                { RTL_CONSTANT_STRING(L"ReattachMaxAttempts"), max_attempts },
                { RTL_CONSTANT_STRING(L"ReattachFirstDelay"), first_delay },
                { RTL_CONSTANT_STRING(L"ReattachMaxDelay"), max_delay },
        };

        for (auto& [name, value]: v) {
                ULONG val{};
                auto st = WdfRegistryQueryULong(key.get<WDFKEY>(), &name, &val);

                if (NT_ERROR(st)) {
                        Trace(TRACE_LEVEL_VERBOSE, "WdfRegistryQueryULong('%!USTR!') %!STATUS!", &name, st);
                } else {
                        value = static_cast<unsigned int>(val);
                }
        }
        
        auto in_range = [] (auto val) { return max(MIN_DELAY, min(val, MAX_DELAY)); };

        first_delay = first_delay ? in_range(first_delay) : DEF_FIRST_DELAY;
        max_delay = max_delay ? in_range(max_delay) : DEF_MAX_DELAY;

        if (first_delay > max_delay) {
                swap(first_delay, max_delay);
        }

        if (auto n = get_max_attach_attempts(first_delay, max_delay, MAX_TOTAL_DELAY); max_attempts > n) {
                max_attempts = n;
        }

        TraceDbg("%!USTR!=%u, %!USTR!=%u, %!USTR!=%u", &v[0].name, max_attempts, &v[1].name, first_delay, &v[2].name, max_delay);

        NT_ASSERT(first_delay >= MIN_DELAY);
        NT_ASSERT(first_delay <= max_delay);
        NT_ASSERT(max_delay <= MAX_DELAY);
}

using init_func_t = NTSTATUS(WDFDEVICE);

_Function_class_(init_func_t)
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED auto init_context(_In_ WDFDEVICE vhci)
{
        PAGED_CODE();
        auto &ctx = *get_vhci_ctx(vhci);

        auto st = alloc_devices(ctx);
        if (NT_ERROR(st)) {
                return st;
        }

        InitializeListHead(&ctx.fileobjects);

        WDF_OBJECT_ATTRIBUTES attr;
        WDF_OBJECT_ATTRIBUTES_INIT(&attr);
        attr.ParentObject = vhci;

        for (WDFSPINLOCK* v[] { &ctx.devices_lock, &ctx.reattach_req_lock }; auto lck: v) {
                st = WdfSpinLockCreate(&attr, lck);
                if (NT_ERROR(st)) {
                        Trace(TRACE_LEVEL_ERROR, "WdfSpinLockCreate %!STATUS!", st);
                        return st;
                }
        }

        st = WdfWaitLockCreate(&attr, &ctx.events_lock);
        if (NT_ERROR(st)) {
                Trace(TRACE_LEVEL_ERROR, "WdfWaitLockCreate %!STATUS!", st);
                return st;
        }

        st = WdfCollectionCreate(&attr, &ctx.reattach_req);
        if (NT_ERROR(st)) {
                Trace(TRACE_LEVEL_ERROR, "WdfCollectionCreate %!STATUS!", st);
                return st;
        }

        st = create_target_self(ctx.target_self, attr, vhci);
        if (NT_ERROR(st)) {
                return st;
        }

        st = create_read_queue(ctx.reads, attr, vhci);
        if (NT_ERROR(st)) {
                return st;
        }

        init_constants(ctx.reattach_max_attempts, ctx.reattach_first_delay, ctx.reattach_max_delay);
        return STATUS_SUCCESS;
}

_Function_class_(init_func_t)
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED auto create_interfaces(_In_ WDFDEVICE vhci)
{
        PAGED_CODE();

        const GUID* v[] = {
                &GUID_DEVINTERFACE_USB_HOST_CONTROLLER,
                &vhci::GUID_DEVINTERFACE_USBIP_VHCI
        };

        for (auto guid: v) {
                auto st = WdfDeviceCreateDeviceInterface(vhci, guid, nullptr);
                if (NT_ERROR(st)) {
                        Trace(TRACE_LEVEL_ERROR, "WdfDeviceCreateDeviceInterface(%!GUID!) %!STATUS!", guid, st);
                        return st;
                }
        }

        return STATUS_SUCCESS;
}

_Function_class_(EVT_UDECX_WDF_DEVICE_QUERY_USB_CAPABILITY)
_IRQL_requires_same_
NTSTATUS query_usb_capability(
        _In_ WDFDEVICE /*UdecxWdfDevice*/,
        _In_ GUID *CapabilityType,
        _In_ ULONG /*OutputBufferLength*/,
        _Out_writes_to_opt_(OutputBufferLength, *ResultLength) PVOID /*OutputBuffer*/,
        _Out_ ULONG *ResultLength)
{
        const GUID* supported[] = {
                &GUID_USB_CAPABILITY_CHAINED_MDLS, 
                &GUID_USB_CAPABILITY_SELECTIVE_SUSPEND, // class extension reports it as supported without invoking the callback
//              &GUID_USB_CAPABILITY_FUNCTION_SUSPEND,
                &GUID_USB_CAPABILITY_DEVICE_CONNECTION_HIGH_SPEED_COMPATIBLE, 
                &GUID_USB_CAPABILITY_DEVICE_CONNECTION_SUPER_SPEED_COMPATIBLE 
        };

        auto st = STATUS_NOT_SUPPORTED;

        for (auto i: supported) {
                if (*i == *CapabilityType) {
                        st = STATUS_SUCCESS;
                        break;
                }
        }

        *ResultLength = 0;
        return st;
}

/*
 * If TargetState is WdfPowerDeviceD3Final, you should assume that the system is being turned off, 
 * the device is about to be removed, or a resource rebalance is in progress.
 * 
 * Cannot be used for actions that are done in EVT_WDF_DEVICE_QUERY_REMOVE 
 * because if the device is in D1-3 state, this callback will not be called again. 
 * The second reason is that if something (app, driver) holds a reference to WDFDEVICE, 
 * EVT_WDF_DEVICE_D0_EXIT(WdfPowerDeviceD3Final) will not be called.
 */
_Function_class_(EVT_WDF_DEVICE_D0_EXIT)
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED NTSTATUS NTAPI vhci_d0_exit(_In_ WDFDEVICE, _In_ WDF_POWER_DEVICE_STATE TargetState)
{
        PAGED_CODE();
        TraceDbg("TargetState %!WDF_POWER_DEVICE_STATE!", TargetState);
        return STATUS_SUCCESS;
}

/*
 * You should not make this callback function pageable.
 */
_Function_class_(EVT_WDF_DEVICE_D0_ENTRY)
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
/*PAGED*/ NTSTATUS NTAPI vhci_d0_entry(_In_ WDFDEVICE, _In_ WDF_POWER_DEVICE_STATE PreviousState)
{
        PAGED_CODE();
        TraceDbg("PreviousState %!WDF_POWER_DEVICE_STATE!", PreviousState);
        return STATUS_SUCCESS;
}

/*
 * Do not call WdfIoQueuePurgeSynchronously from the following queue object event callback functions,
 * regardless of the queue with which the event callback function is associated:
 * EvtIoDefault, EvtIoDeviceControl, EvtIoInternalDeviceControl, EvtIoRead, EvtIoWrite.
 */
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED void purge_read_queue(_In_ WDFDEVICE vhci)
{
        PAGED_CODE();

        auto &ctx = *get_vhci_ctx(vhci);
        TraceDbg("%04x", ptr04x(ctx.reads));

        wdf::waitlock lck(ctx.events_lock);
        WdfIoQueuePurgeSynchronously(ctx.reads);
}

/* 
 * Windows does not call the EvtDeviceQueryRemove callback
 * during a standard system reboot or shutdown.
 * 
 * This callback determines whether a specified device can be stopped and removed.
 * The framework does not synchronize the EvtDeviceQueryRemove callback function 
 * with other PnP and power management callback functions.
 * 
 * VHCI device will not be removed until all FILEOBJECT-s will be closed.
 * The uninstaller will block on the command that removes VHCI device node.
 * Cancelling read requests forces apps to close handle of VHCI device.
 *
 * FIXME: can be called several times (if IRP_MN_CANCEL_REMOVE_DEVICE was issued?).
 */
_Function_class_(EVT_WDF_DEVICE_QUERY_REMOVE)
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED NTSTATUS vhci_query_remove(_In_ WDFDEVICE vhci)
{
        PAGED_CODE();
        TraceDbg("%04x", ptr04x(vhci));
        
        auto &ctx = *get_vhci_ctx(vhci);
        set_flag(ctx.removing);
        stop_attach_attempts(ctx, 0);

        async_detach_and_delete_all(vhci);
        purge_read_queue(vhci); // detach notifications may not be received

        return STATUS_SUCCESS;
}

_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED auto create_collection(_Out_ WDFCOLLECTION &result, _In_ WDFOBJECT parent)
{
        PAGED_CODE();

        WDF_OBJECT_ATTRIBUTES attr;
        WDF_OBJECT_ATTRIBUTES_INIT(&attr);
        attr.ParentObject = parent;

        return WdfCollectionCreate(&attr, &result);
}

_Function_class_(EVT_WDF_DEVICE_FILE_CREATE)
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED void device_file_create(_In_ WDFDEVICE vhci, _In_ WDFREQUEST request, _In_ WDFFILEOBJECT fileobj)
{
        PAGED_CODE();
        TraceDbg("vhci %04x, fobj %04x", ptr04x(vhci), ptr04x(fileobj));

        auto &fobj = *get_fileobject_ctx(fileobj);
        InitializeListHead(&fobj.entry);

        auto st = create_collection(fobj.events, fileobj);

        if (NT_ERROR(st)) {
                Trace(TRACE_LEVEL_ERROR, "WdfCollectionCreate %!STATUS!", st);
        } else if (auto v = get_vhci_ctx(vhci)) {
                wdf::waitlock lck(v->events_lock);
                InsertTailList(&v->fileobjects, &fobj.entry);
        }

        WdfRequestComplete(request, st);
}

_Function_class_(EVT_WDF_FILE_CLEANUP)
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED void file_cleanup(_In_ WDFFILEOBJECT fileobj)
{
        PAGED_CODE();
        TraceDbg("fobj %04x", ptr04x(fileobj));

        auto &fobj = *get_fileobject_ctx(fileobj); 
        auto vhci = WdfFileObjectGetDevice(fileobj);
        auto &ctx = *get_vhci_ctx(vhci);

        wdf::waitlock lck(ctx.events_lock);

        RemoveEntryList(&fobj.entry);
        InitializeListHead(&fobj.entry);
        
        if (fobj.process_events) {
                --ctx.events_subscribers;
        }
}

/*
 * Drivers for USB devices must not specify IdleCanWakeFromS0. 
 */
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED auto initialize(_Inout_ WDFDEVICE_INIT *init)
{
        PAGED_CODE();

        {
                WDF_PNPPOWER_EVENT_CALLBACKS cb;
                WDF_PNPPOWER_EVENT_CALLBACKS_INIT(&cb);

                cb.EvtDeviceD0Exit = vhci_d0_exit;
                cb.EvtDeviceD0Entry = vhci_d0_entry;
                cb.EvtDeviceQueryRemove = vhci_query_remove;

                WdfDeviceInitSetPnpPowerEventCallbacks(init, &cb);
        }

        {
                WDF_REMOVE_LOCK_OPTIONS opts;
                WDF_REMOVE_LOCK_OPTIONS_INIT(&opts, WDF_REMOVE_LOCK_OPTION_ACQUIRE_FOR_IO);
                WdfDeviceInitSetRemoveLockOptions(init, &opts);
        }

        {
                WDF_OBJECT_ATTRIBUTES attr;
                WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&attr, request_ctx);
                WdfDeviceInitSetRequestAttributes(init, &attr);
        }

        {
                WDF_FILEOBJECT_CONFIG cfg;
                WDF_FILEOBJECT_CONFIG_INIT(&cfg, device_file_create, WDF_NO_EVENT_CALLBACK, file_cleanup);
                cfg.FileObjectClass = WdfFileObjectWdfCanUseFsContext;

                WDF_OBJECT_ATTRIBUTES attr;
                WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&attr, fileobject_ctx);

                WdfDeviceInitSetFileObjectConfig(init, &cfg, &attr);
        }

        WdfDeviceInitSetCharacteristics(init, FILE_AUTOGENERATED_DEVICE_NAME, true);

        /*
         * Security Note:
         * SDDL_DEVOBJ_SYS_ALL_ADM_RWX_WORLD_RW_RES_R grants World (Everyone / unprivileged users)
         * Read and Write access (D:P(A;;GA;;;SY)(A;;GRGWGX;;;BA)(A;;GRGW;;;WD)(A;;GR;;;RC)).
         * This is an intentional usability design choice for desktop client scenarios: any local user
         * can attach/detach remote USB devices via usbip/wusbip without requiring UAC elevation,
         * matching the physical USB plug/unplug user experience.
         *
         * Security trade-offs:
         * 1. Kernel-mode outbound connection primitive: PLUGIN_HARDWARE allows unprivileged callers
         *    to instruct the driver (running as SYSTEM in kernel mode) to open outbound TCP connections
         *    to arbitrary hosts/ports (potential SSRF / network reconnaissance).
         * 2. System persistence modification: SET_PERSISTENT allows unprivileged callers to write
         *    arbitrary persistent device lists into HKLM (see set_persistent in vhci_ioctl.cpp).
         * 3. Cross-user device manipulation: on multi-user systems, callers can disconnect or abort
         *    attach attempts for devices imported by other users (no per-caller ownership check).
         *
         * How 1 (PLUGIN_HARDWARE / outbound connection primitive) can be restricted:
         * - Device ACL: Change SDDL to SDDL_DEVOBJ_SYS_ALL_ADM_RWX_WORLD_R (World Read-only, Admins RWX),
         *   requiring administrative privilege to open the device for write/IOCTL dispatch.
         * - Caller privilege check: Verify caller holds administrative privileges or specific rights
         *   (e.g., SeSinglePrivilegeCheck for SE_LOAD_DRIVER_PRIVILEGE or token membership in Administrators)
         *   in plugin_hardware() before initiating connection.
         * - Caller impersonation: Use WdfRequestImpersonate() before socket connect so that outbound
         *   network traffic is attributed to the user's security token and evaluated against user-level
         *   firewall / Windows Filtering Platform (WFP) rules rather than kernel SYSTEM context.
         * - Destination filtering: Validate target host/port in plugin_hardware() (e.g., enforce
         *   standard USB/IP port 3240, block loopback 127.0.0.1 / ::1, link-local, or private subnets).
         */
        auto st = WdfDeviceInitAssignSDDLString(init, &SDDL_DEVOBJ_SYS_ALL_ADM_RWX_WORLD_RW_RES_R);
        if (NT_ERROR(st)) {
                Trace(TRACE_LEVEL_ERROR, "WdfDeviceInitAssignSDDLString %!STATUS!", st);
                return st;
        }

        st = UdecxInitializeWdfDeviceInit(init);
        if (NT_ERROR(st)) {
                Trace(TRACE_LEVEL_ERROR, "UdecxInitializeWdfDeviceInit %!STATUS!", st);
        }
        return st;
}

_Function_class_(init_func_t)
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED auto add_usbdevice_emulation(_In_ WDFDEVICE vhci)
{
        PAGED_CODE();
        auto &ctx = *get_vhci_ctx(vhci);

        UDECX_WDF_DEVICE_CONFIG cfg;
        UDECX_WDF_DEVICE_CONFIG_INIT(&cfg, query_usb_capability);

        cfg.NumberOfUsb20Ports = static_cast<USHORT>(ctx.usb2_ports);
        cfg.NumberOfUsb30Ports = static_cast<USHORT>(ctx.devices_cnt - ctx.usb2_ports);

        NT_ASSERT(cfg.NumberOfUsb20Ports + cfg.NumberOfUsb30Ports == ctx.devices_cnt);

        auto st = UdecxWdfDeviceAddUsbDeviceEmulation(vhci, &cfg);

        if (NT_ERROR(st)) {
                Trace(TRACE_LEVEL_ERROR, "UdecxWdfDeviceAddUsbDeviceEmulation %!STATUS!", st);
        } else {
                Trace(TRACE_LEVEL_INFORMATION, "NumberOfUsb20Ports %d, NumberOfUsb30Ports %d", 
                                                cfg.NumberOfUsb20Ports, cfg.NumberOfUsb30Ports);
        }

        return st;
}

_Function_class_(init_func_t)
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED auto configure(_In_ WDFDEVICE vhci)
{
        PAGED_CODE();

        {
                WDF_DEVICE_POWER_POLICY_IDLE_SETTINGS idle_settings;
                WDF_DEVICE_POWER_POLICY_IDLE_SETTINGS_INIT(&idle_settings, IdleCannotWakeFromS0);

                auto st = WdfDeviceAssignS0IdleSettings(vhci, &idle_settings);
                if (NT_ERROR(st)) {
                        Trace(TRACE_LEVEL_ERROR, "WdfDeviceAssignS0IdleSettings %!STATUS!", st);
                        return st;
                }
        }

/*
        {
                WDF_DEVICE_POWER_POLICY_WAKE_SETTINGS wake;
                WDF_DEVICE_POWER_POLICY_WAKE_SETTINGS_INIT(&wake);
                wake.

                if (auto err = WdfDeviceAssignSxWakeSettings(vhci, &wake)) {
                        Trace(TRACE_LEVEL_ERROR, "WdfDeviceAssignSxWakeSettings %!STATUS!", err);
                        return err;
                }
        }

        {
                WDF_DEVICE_POWER_CAPABILITIES caps;
                WDF_DEVICE_POWER_CAPABILITIES_INIT(&caps);
                WdfDeviceSetPowerCapabilities(vhci, &caps);
        }

        {
                WDF_DEVICE_PNP_CAPABILITIES caps;
                WDF_DEVICE_PNP_CAPABILITIES_INIT(&caps);
                WdfDeviceSetPnpCapabilities(vhci, &caps);
        }
*/
        return STATUS_SUCCESS;
}

_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED auto create_vhci(_Out_ WDFDEVICE &vhci, _In_ WDFDEVICE_INIT *init)
{
        PAGED_CODE();

        WDF_OBJECT_ATTRIBUTES attr; // default parent (WDFDRIVER) is OK
        WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&attr, vhci_ctx);
        attr.EvtCleanupCallback = vhci_cleanup;

        auto st = WdfDeviceCreate(&init, &attr, &vhci);
        if (NT_ERROR(st)) {
                Trace(TRACE_LEVEL_ERROR, "WdfDeviceCreate %!STATUS!", st);
                return st;
        }

        init_func_t* const functions[] { init_context, configure, create_interfaces, 
                                         add_usbdevice_emulation, vhci::create_queues };

        for (auto f: functions) {
                st = f(vhci);
                if (NT_ERROR(st)) {
                        return st;
                }
        }

        return STATUS_SUCCESS;
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
auto get_port_range(_In_ const vhci_ctx &vhci, _In_ usb_device_speed speed)
{
        struct{ int begin;  int end; } r;

        if (speed < USB_SPEED_SUPER) {
                r.begin = 0;
                r.end = vhci.usb2_ports;
        } else {
                r.begin = vhci.usb2_ports;
                r.end = vhci.devices_cnt;
        }

        return r;
}

/**
 * Similar to RtlIntPtrToUnicodeString and RtlHashUnicodeString.
 * @return hash value
 */
_IRQL_requires_same_
auto make_source_id(_In_ const void *ptr)
{
        auto val = reinterpret_cast<uintptr_t>(ptr);
        static_assert(sizeof(val) == sizeof(ULONG64));
        return static_cast<ULONG>(val ^ (val >> 32));
}

_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED auto make_device_state(
        _In_ WDFOBJECT parent, _In_ const device_attributes &dev, _In_ int port, _In_ vhci::state state)
{
        PAGED_CODE();

        WDF_OBJECT_ATTRIBUTES attr;
        WDF_OBJECT_ATTRIBUTES_INIT(&attr);
        attr.EvtDestroyCallback = [] (auto p) { TraceDbg("destroy %04x", ptr04x(p)); };
        attr.ParentObject = parent;

        WDFMEMORY mem{};
        vhci::device_state *r{};
        wdf::object_delete result;

        auto st = WdfMemoryCreate(&attr, PagedPool, 0, sizeof(*r), &mem, reinterpret_cast<PVOID*>(&r));
        if (!NT_SUCCESS(st)) {
                Trace(TRACE_LEVEL_ERROR, "WdfMemoryCreate %!STATUS!", st);
                return result;
        }
        result.reset(mem);

        RtlZeroMemory(r, sizeof(*r));
        r->size = sizeof(*r);
        r->state = state;
        r->source_id = make_source_id(&dev); // CONTAINING_RECORD(&dev, device_ctx_ext, attr)

        st = fill(*r, dev, port);

        if (NT_SUCCESS(st)) {
                TraceDbg("%04x", ptr04x(mem));
        } else {
                result.reset();
        }

        return result;
}

_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED const auto& get_device_state(_In_ WDFMEMORY mem)
{
        PAGED_CODE();
        NT_ASSERT(mem);

        size_t size;
        auto state = static_cast<const vhci::device_state*>(WdfMemoryGetBuffer(mem, &size));

        NT_ASSERT(size == sizeof(*state));
        return *state;
}

_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED void sweep_redundant_events(_Inout_ fileobject_ctx &fobj, _In_ WDFMEMORY new_evt, _In_ ULONG count)
{
        PAGED_CODE();
        NT_ASSERT(count);

        auto fileobj = get_handle(&fobj);
        auto events = fobj.events;

        auto &new_st = get_device_state(new_evt);
        NT_ASSERT(new_st.location_hash);

        for (auto i = count; i--; ) {
                auto mem_i = static_cast<WDFMEMORY>(WdfCollectionGetItem(events, i));
                auto &st_i = get_device_state(mem_i);

                NT_ASSERT(st_i.location_hash);
                auto is_redundant = st_i.location_hash == new_st.location_hash;

                if (!is_redundant) {
                        for (auto cnt = WdfCollectionGetCount(events), j = i + 1; j < cnt; ++j) {
                                auto mem_j = static_cast<WDFMEMORY>(WdfCollectionGetItem(events, j));
                                if (st_i.location_hash == get_device_state(mem_j).location_hash) {
                                        is_redundant = true;
                                        break;
                                }
                        }
                }

                if (is_redundant) {
                        WdfCollectionRemoveItem(events, i);
                        TraceDbg("fobj %04x, drop %04x[%lu]", ptr04x(fileobj), ptr04x(mem_i), i);
                }
        }
}

constexpr ULONG get_max_events(_In_ int devices_cnt)
{
        enum { MIN_EVENTS = 64 };
        return max(MIN_EVENTS, 4*devices_cnt);
}

/*
 * vhci_ctx::events_lock must be acquired.
 */
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED void process_event(
        _In_ WDFQUEUE queue, _Inout_ fileobject_ctx &fobj, _In_ WDFMEMORY evt, _In_ ULONG max_events)
{
        PAGED_CODE();

        auto fileobj = get_handle(&fobj);
        WDFREQUEST request{};

        switch (auto st = WdfIoQueueRetrieveRequestByFileObject(queue, fileobj, &request)) {
        case STATUS_SUCCESS:
                NT_ASSERT(!WdfCollectionGetCount(fobj.events));
                vhci::complete_read(request, evt);
                break;
        case STATUS_NO_MORE_ENTRIES:
                if (auto cnt = WdfCollectionGetCount(fobj.events); cnt >= max_events) {
                        sweep_redundant_events(fobj, evt, cnt);
                }

                st = WdfCollectionAdd(fobj.events, evt); // append and increment reference count

                if (!NT_SUCCESS(st)) {
                        Trace(TRACE_LEVEL_ERROR, "WdfCollectionAdd %!STATUS!", st);
                } else if (auto cnt = WdfCollectionGetCount(fobj.events); cnt > max_events) {
                        auto head = WdfCollectionGetFirstItem(fobj.events);
                        WdfCollectionRemoveItem(fobj.events, 0); // is a head, decrements reference count

                        TraceDbg("fobj %04x, drop %04x[0], add %04x[%lu]",
                                  ptr04x(fileobj), ptr04x(head), ptr04x(evt), --cnt - 1);
                } else {
                        TraceDbg("fobj %04x, add %04x[%lu]", ptr04x(fileobj), ptr04x(evt), cnt - 1);
                }

                break;
        default:
                Trace(TRACE_LEVEL_ERROR, "WdfIoQueueRetrieveRequestByFileObject %!STATUS!", st);
        }
}

_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED void process_event(_In_ vhci_ctx &vhci, _In_ WDFMEMORY evt)
{
        PAGED_CODE();

        auto max_events = get_max_events(vhci.devices_cnt);
        int cnt = 0;

        wdf::waitlock lck(vhci.events_lock);

        for (auto head = &vhci.fileobjects, entry = head->Flink; entry != head; entry = entry->Flink) {
                auto &fobj = *CONTAINING_RECORD(entry, fileobject_ctx, entry);
                if (fobj.process_events) {
                        process_event(vhci.reads, fobj, evt, max_events);
                        ++cnt;
                }
        }

        NT_ASSERT(cnt == vhci.events_subscribers);
}

} // namespace


/*
 * usb2.0 devices don't work in usb3.x ports, and visa versa, tested.
 */
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
int usbip::vhci::claim_roothub_port(_In_ UDECXUSBDEVICE device)
{
        auto &dev = *get_device_ctx(device);
        auto &vhci = *get_vhci_ctx(dev.vhci); 

        NT_ASSERT(!dev.port);
        int port = 0;

        auto [begin, end] = get_port_range(vhci, dev.speed());

        wdf::spinlock lck(vhci.devices_lock); // function must be resident, do not use PAGED
 
        for (auto i = begin; i < end; ++i) {
                NT_ASSERT(i < vhci.devices_cnt);

                if (auto &handle = vhci.devices[i]; !handle) {
                        WdfObjectReference(handle = device);
                        
                        port = i + 1;
                        NT_ASSERT(is_valid_port(vhci, port));
                        dev.port = port;
                        break;
                }
        }

        return port;
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
int usbip::vhci::reclaim_roothub_port(_In_ UDECXUSBDEVICE device)
{
        auto &dev = *get_device_ctx(device);
        auto &vhci = *get_vhci_ctx(dev.vhci); 

        int portnum = 0;

        wdf::spinlock lck(vhci.devices_lock); 
        if (auto &port = dev.port) {
                NT_ASSERT(is_valid_port(vhci, port));
                portnum = port;

                auto &handle = vhci.devices[port - 1];
                NT_ASSERT(handle == device);

                handle = WDF_NO_HANDLE;
                port = 0;
        }

        if (portnum) {
                WdfObjectDereference(device);
        }
        
        return portnum;
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
bool usbip::vhci::has_device(_In_ WDFDEVICE vhci, _In_ ULONG location_hash)
{
        NT_ASSERT(location_hash);

        auto &ctx = *get_vhci_ctx(vhci);
        wdf::spinlock lck(ctx.devices_lock); 

        for (int i = 0; i < ctx.devices_cnt; ++i) {

                if (auto hdev = ctx.devices[i]) {
                        auto dev = get_device_ctx(hdev);
                        if (auto &ext = dev->ext(); ext.location_hash() == location_hash) {
                                return true;
                        }
                }
        }

        return false;
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
wdf::ObjectRef usbip::vhci::get_device(_In_ WDFDEVICE vhci, _In_ int port)
{
        auto &ctx = *get_vhci_ctx(vhci);

        wdf::ObjectRef ptr;
        if (!is_valid_port(ctx, port)) {
                return ptr;
        }

        wdf::spinlock lck(ctx.devices_lock); 
        if (auto handle = ctx.devices[port - 1]) {
                NT_ASSERT(get_device_ctx(handle)->port == port);
                ptr.reset(handle); // adds reference
        }

        return ptr;
}

_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED void usbip::vhci::detach_all_devices(_In_ WDFDEVICE vhci, _In_ bool plugout_and_delete)
{
        PAGED_CODE();

        TraceDbg("%04x", ptr04x(vhci));
        auto &ctx = *get_vhci_ctx(vhci);

        for (int port = 1; port <= ctx.devices_cnt; ++port) {
                if (auto dev = get_device(vhci, port)) {
                        device::detach(dev.get<UDECXUSBDEVICE>(), plugout_and_delete);
                }
        }
}

_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED NTSTATUS usbip::vhci::fill(_Out_ imported_device &dev, _In_ const device_attributes &r, _In_ int port)
{
        PAGED_CODE();
        dev.port = port;

        auto st = fill_location(dev, r);
        if (NT_SUCCESS(st)) {
                static_cast<imported_device_properties&>(dev) = r.properties;
        }
        return st;
}

_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED void usbip::vhci::complete_read(_In_ WDFREQUEST request, _In_ WDFMEMORY evt)
{
        PAGED_CODE();

        device_state *dst{};
        auto dst_sz = sizeof(*dst);

        auto st = WdfRequestRetrieveOutputBuffer(request, dst_sz, reinterpret_cast<PVOID*>(&dst), nullptr);
        
        if (NT_SUCCESS(st)) {
                *dst = get_device_state(evt);
        } else {
                Trace(TRACE_LEVEL_ERROR, "WdfRequestRetrieveOutputBuffer %!STATUS!", st);
                dst_sz = 0;
        }

        TraceDbg("fobj %04x, req %04x, device_state %04x, %!STATUS!", ptr04x(WdfRequestGetFileObject(request)), 
                  ptr04x(request), ptr04x(evt), st);

        WdfRequestCompleteWithInformation(request, st, dst_sz);
}

/*
 * vhci_ctx::events_lock must be acquired.
 */
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED void usbip::vhci::replay_plugged_devices(_In_ WDFDEVICE vhci, _Inout_ fileobject_ctx &fobj)
{
        PAGED_CODE();

        auto &ctx = *get_vhci_ctx(vhci);

        for (int port = 1; port <= ctx.devices_cnt; ++port) {
                if (auto dev = get_device(vhci, port)) {
                        auto dc = get_device_ctx(dev.get());
                        if (auto evt = make_device_state(vhci, dc->attributes(), dc->port, state::plugged)) {
                                auto st = WdfCollectionAdd(fobj.events, evt.get<WDFMEMORY>());
                                if (!NT_SUCCESS(st)) {
                                        Trace(TRACE_LEVEL_ERROR, "WdfCollectionAdd %!STATUS!", st);
                                }
                        }
                }
        }
}

/*
 * Each WDFMEMORY object is shared between FILEOBJECT-s, thus parent is set to WDFDEVICE.
 */
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED void usbip::vhci::device_state_changed(
        _In_ WDFDEVICE vhci, _In_ const device_attributes &attr, _In_ int port, _In_ state state)
{
        PAGED_CODE();
        auto &ctx = *get_vhci_ctx(vhci);

        auto subscribers = ctx.events_subscribers; // lock-free check, reading 32-bit aligned int is atomic
        if (!subscribers) {
                return;
        }

        TraceDbg("%!USTR!:%!USTR!/%!USTR!, port %d, %!vhci_state!, subscribers %d",
                  &attr.node_name, &attr.service_name, &attr.busid, port, int(state), subscribers);

        if (auto evt = make_device_state(vhci, attr, port, state)) {
                process_event(ctx, evt.get<WDFMEMORY>());
        } else {
                Trace(TRACE_LEVEL_ERROR, "Failed to create state '%!vhci_state!'", int(state));
        }
}

/*
 * Drivers cannot call WdfObjectDelete to delete WDFDEVICE.
 * WdfObjectDelete: Attempt to Delete an Object Which does not allow WdfDeleteObject, STATUS_CANNOT_DELETE.
 */
_Function_class_(EVT_WDF_DRIVER_DEVICE_ADD)
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
PAGED NTSTATUS usbip::DeviceAdd(_In_ WDFDRIVER, _Inout_ WDFDEVICE_INIT *init)
{
        PAGED_CODE();

        auto st = initialize(init);
        if (NT_ERROR(st)) {
                return st;
        }

        WDFDEVICE vhci{};
        st = create_vhci(vhci, init);

        if (NT_SUCCESS(st)) { // the framework handles deletion of WDFDEVICE in case of an error
                Trace(TRACE_LEVEL_INFORMATION, "vhci %04x", ptr04x(vhci));
                plugin_persistent_devices(vhci);
        }

        return st;
}
