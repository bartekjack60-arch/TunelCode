# AutoTunel MB 0.6 — USB w jednym EXE

Ten sam **AutoTunel.exe** działa na obu komputerach. Obsługa USB jest wbudowana:
AutoTunel sam przygotowuje narzędzia, usługę i sterowniki z pakietów zapisanych
wewnątrz EXE. Nie trzeba osobno pobierać instalatorów USB/IP ani wskazywać
ich programów. Przygotowanie USB nie pobiera pakietów z Internetu.

1. Skopiuj `AutoTunel.exe` na oba komputery Windows 10 (od 1903)/11 x64
   z .NET Framework 4.8.
2. Połącz komputery przez RadminVPN. Uruchom AutoTunel i zaakceptuj uprawnienia
   administratora wymagane do obsługi sterowników.
3. Przy samochodzie wybierz **Przy samochodzie**. Program automatycznie
   przygotuje USB i pokaże dostępne urządzenia.
4. U diagnosty wybierz **Diagnosta**, wklej kod i kliknij **Połącz z samochodem**.
   Obsługa USB zostanie przygotowana automatycznie przed połączeniem.
5. Jeśli pojawi się komunikat o restarcie, wybierz w Windows **Uruchom ponownie**
   i otwórz ponownie AutoTunel. Komponent klienta wymaga tego po pierwszej
   instalacji. AutoTunel nie restartuje komputera samodzielnie.
6. Wybierz Openport przy samochodzie, kliknij **Udostępnij interfejs**, przekaż
   kod diagnoście i połącz się. Po zakończeniu pracy kliknij **Rozłącz**.

Przygotowanie można wykonać wcześniej: **Ustawienia USB → Przygotuj USB**.
Kolejne uruchomienia korzystają z zainstalowanej obsługi. Działające instalacje
usbipd-win 5.3.0 i usbip-win2 0.9.8.1 z wcześniejszej wersji są zachowywane.
Inne lub niesprawne istniejące instalacje wymagają osobnego sprawdzenia;
AutoTunel zgłasza przyczynę i wymaganą wersję.

Windows nadal instaluje sterownik w systemie — odbywa się to automatycznie
z EXE. Do uruchomienia wystarcza ten plik; pomoc i licencje są wbudowane.
Nie są potrzebne `.exe.config`, Python, WSL ani .NET SDK.

Wymagane są nadal RadminVPN, sterownik posiadanego interfejsu, np. Openporta,
oraz program diagnostyczny. Zmiana obejmuje obsługę USB/IP. Tryb ENET nadal
wymaga Npcap przy samochodzie i TAP-Windows6 u diagnosty.

Sesja używa TCP 24832 na wybranej karcie RadminVPN. USB/IP używa TCP 3240.
Oficjalny instalator usbipd-win tworzy standardową regułę zapory; AutoTunel
nie włącza ani nie wyłącza Zapory Windows. Przy wyłączonej zaporze bezpośredni
port 3240 jest dostępny z sieci i nie chroni go kod AutoTunel. Używaj zaufanej sieci.

Kompilację, testy logiki i transportu oraz zawartość EXE sprawdzono w Linux.
Instalacja sterowników, restart, GUI i fizyczny Openport/Xentry wymagają próby
na Windows według [WINDOWS-TEST.md](WINDOWS-TEST.md). Raport: [TESTY.txt](TESTY.txt).
EXE prototypu nie ma podpisu wydawcy AutoTunel.

Źródła aplikacji: `source/src`. Źródła komponentów i licencje: `vendor/sources`
i `vendor/licenses`. Budowanie: [DEVELOPMENT.md](DEVELOPMENT.md).
