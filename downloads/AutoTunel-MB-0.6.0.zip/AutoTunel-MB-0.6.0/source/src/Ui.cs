using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace AutoTunel {
 internal static class Ui {
  internal static readonly Color Navy=Color.FromArgb(17,30,48), Teal=Color.FromArgb(0,117,112), Ink=Color.FromArgb(26,43,60), Muted=Color.FromArgb(100,116,134), Canvas=Color.FromArgb(242,246,249), Line=Color.FromArgb(219,228,235);
  internal static Label Label(string text,float size=10,bool bold=false){return new Label{Text=text,AutoSize=true,Font=new Font("Segoe UI",size,bold?FontStyle.Bold:FontStyle.Regular),ForeColor=Ink,Margin=new Padding(0,0,0,6),UseMnemonic=false};}
  internal static void Button(Button button,bool primary=false){button.AutoSize=false;button.Height=42;button.FlatStyle=FlatStyle.Flat;button.FlatAppearance.BorderSize=primary?0:1;button.FlatAppearance.BorderColor=Line;button.BackColor=primary?Teal:Color.White;button.ForeColor=primary?Color.White:Ink;button.Font=new Font("Segoe UI",10,FontStyle.Bold);button.Cursor=Cursors.Hand;button.Margin=new Padding(0,0,10,0);button.UseVisualStyleBackColor=false;button.FlatAppearance.MouseOverBackColor=primary?Color.FromArgb(0,96,93):Color.FromArgb(230,241,242);}
  internal static TableLayoutPanel Stack(){var panel=new TableLayoutPanel{ColumnCount=1,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,Margin=Padding.Empty};panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));return panel;}
  internal static void Add(TableLayoutPanel parent,Control control){int row=parent.RowCount++;parent.RowStyles.Add(new RowStyle(SizeType.AutoSize));control.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right;parent.Controls.Add(control,0,row);}
  internal static Panel Card(string heading,Control body){var contents=Stack();var title=Label(heading,10,true);title.ForeColor=Muted;title.Margin=new Padding(0,0,0,10);Add(contents,title);Add(contents,body);var card=new BorderPanel{BackColor=Color.White,Padding=new Padding(16),AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,Margin=new Padding(0,0,0,14)};card.Controls.Add(contents);return card;}
  internal static Size Fit(Size desired){var area=Screen.PrimaryScreen.WorkingArea;return new Size(Math.Min(desired.Width,area.Width-24),Math.Min(desired.Height,area.Height-24));}
 }
 internal sealed class BorderPanel:Panel {
  internal BorderPanel(){DoubleBuffered=true;}
  protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);using(var pen=new Pen(Ui.Line))e.Graphics.DrawRectangle(pen,0,0,Math.Max(0,Width-1),Math.Max(0,Height-1));}
 }
 internal sealed class BrandMark:Control {
  internal BrandMark(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);Size=new Size(48,48);TabStop=false;}
  protected override void OnPaint(PaintEventArgs e){
   base.OnPaint(e);var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;
   float s=Math.Min(Width,Height)/48f;
   using(var p=new Pen(Color.FromArgb(65,209,190),3*s)){
    g.DrawRectangle(p,8*s,11*s,11*s,25*s);g.DrawRectangle(p,29*s,11*s,11*s,25*s);
    g.DrawLine(p,19*s,19*s,29*s,19*s);g.DrawLine(p,19*s,28*s,29*s,28*s);
   }
  }
 }
 internal sealed class RolePicker:Form {
  internal bool Server{get;private set;}
  internal RolePicker(){
   Text="AutoTunel MB • wybierz rolę";Font=new Font("Segoe UI",10);AutoScaleDimensions=new SizeF(96,96);AutoScaleMode=AutoScaleMode.Dpi;BackColor=Ui.Canvas;
   StartPosition=FormStartPosition.CenterScreen;Size=Ui.Fit(new Size(850,590));MinimumSize=new Size(760,530);MaximizeBox=false;
   var root=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=4,Padding=new Padding(30)};root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
   root.RowStyles.Add(new RowStyle(SizeType.Absolute,72));root.RowStyles.Add(new RowStyle(SizeType.Absolute,94));root.RowStyles.Add(new RowStyle(SizeType.Percent,100));root.RowStyles.Add(new RowStyle(SizeType.Absolute,42));Controls.Add(root);
   var brand=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,BackColor=Ui.Navy,Padding=new Padding(12,5,0,0),Margin=new Padding(0,0,0,16)};
   brand.Controls.Add(new BrandMark());var name=Ui.Label("AutoTunel MB",20,true);name.ForeColor=Color.White;name.Margin=new Padding(8,7,0,0);brand.Controls.Add(name);root.Controls.Add(brand,0,0);
   var introduction=Ui.Stack();var title=Ui.Label("Gdzie teraz pracujesz?",23,true);Ui.Add(introduction,title);var subtitle=Ui.Label("Ten sam program uruchamiasz na obu komputerach. Wybierz rolę tego komputera.");subtitle.ForeColor=Ui.Muted;Ui.Add(introduction,subtitle);root.Controls.Add(introduction,0,1);
   var choices=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=Padding.Empty};choices.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));choices.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));
   choices.Controls.Add(Choice(true),0,0);choices.Controls.Add(Choice(false),1,0);root.Controls.Add(choices,0,2);
   var hint=Ui.Label("USB / J2534  +  ENET     •     Połącz oba komputery przez RadminVPN.",9);hint.ForeColor=Ui.Muted;hint.Dock=DockStyle.Bottom;root.Controls.Add(hint,0,3);
  }
  Control Choice(bool server){
   var card=new BorderPanel{BackColor=Color.White,Dock=DockStyle.Fill,Padding=new Padding(20),Margin=server?new Padding(0,0,8,0):new Padding(8,0,0,0)};
   var layout=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=4};layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,30));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,40));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,44));
   var tag=Ui.Label(server?"01  /  SERVER":"02  /  CLIENT",9,true);tag.ForeColor=Ui.Teal;layout.Controls.Add(tag,0,0);
   layout.Controls.Add(Ui.Label(server?"Przy samochodzie":"Diagnosta",19,true),0,1);
   var description=Ui.Label(server?"Mam podłączony interfejs lub kabel ENET. Udostępnię go i przekażę kod diagnoście.":"Pracuję na swoim komputerze. Połączę się kodem i uruchomię program diagnostyczny.");description.AutoSize=false;description.Dock=DockStyle.Fill;description.ForeColor=Ui.Muted;layout.Controls.Add(description,0,2);
   var button=new Button{Text=server?"Udostępnij z tego komputera":"Połącz jako diagnosta",Dock=DockStyle.Fill,AccessibleName=server?"Wybierz rolę: przy samochodzie, Server":"Wybierz rolę: diagnosta, Client"};Ui.Button(button,true);button.Margin=Padding.Empty;
   button.Click+=delegate{Server=server;DialogResult=DialogResult.OK;Close();};layout.Controls.Add(button,0,3);card.Controls.Add(layout);return card;
  }
 }
}
