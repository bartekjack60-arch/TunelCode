using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace AutoTunel {
 public sealed class MainForm:Form {
  readonly bool server;
  readonly ComboBox mode=new ComboBox(),vpn=new ComboBox(),equipment=new ComboBox();
  readonly TextBox code=new TextBox(),tool=new TextBox(),log=new TextBox();
  readonly Button changeRole=new Button(),start=new Button(),stop=new Button(),refresh=new Button(),copy=new Button(),recover=new Button();
  readonly Button prepareUsb=new Button();
  readonly Label statusTitle=new Label(),deviceHint=new Label(),status=new Label(),deviceLabel=new Label(),transfer=new Label();
  readonly GroupBox settings=new GroupBox();readonly CheckBox details=new CheckBox(),advanced=new CheckBox();
  readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer{Interval=500};
  Tunnel tunnel;UsbIpBackend backend;SharedUsb share;UsbAttachment attachment;
  CancellationTokenSource cancellation;Task sessionTask;bool busy,refreshing,closing,usbRestartRequired;string pendingCode;
  const int SessionPort=24832;
  bool UsbMode{get{return mode.SelectedIndex==0;}}
  string Journal{get{return Path.Combine(Platform.DataDir,server?"owned-usb-share.txt":"owned-usb-client.txt");}}

  public bool ChangeRoleRequested{get;private set;}
  public MainForm(bool atVehicle){
   server=atVehicle;
   Text="AutoTunel MB 0.6 • "+(server?"Przy samochodzie":"Diagnosta");
   Size=Ui.Fit(new Size(1140,820));MinimumSize=new Size(960,680);StartPosition=FormStartPosition.CenterScreen;
   AutoScaleDimensions=new SizeF(96,96);AutoScaleMode=AutoScaleMode.Dpi;Font=new Font("Segoe UI",10);ForeColor=Ui.Ink;BackColor=Ui.Canvas;
   var shell=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=Padding.Empty};shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,224));shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));Controls.Add(shell);
   var sidebar=new Panel{Dock=DockStyle.Fill,BackColor=Ui.Navy,Padding=new Padding(22),Margin=Padding.Empty};shell.Controls.Add(sidebar,0,0);
   var side=Ui.Stack();side.Dock=DockStyle.Fill;
   Ui.Add(side,new BrandMark{Margin=new Padding(0,4,0,18)});
   var brand=Ui.Label("AutoTunel",24,true);brand.ForeColor=Color.White;Ui.Add(side,brand);
   var brandSub=Ui.Label("MB  /  ZDALNA DIAGNOSTYKA",8,true);brandSub.ForeColor=Color.FromArgb(139,161,182);brandSub.Margin=new Padding(0,0,0,36);Ui.Add(side,brandSub);
   var roleTag=Ui.Label(server?"SERVER":"CLIENT",9,true);roleTag.ForeColor=Color.FromArgb(65,209,190);Ui.Add(side,roleTag);
   var roleTitle=Ui.Label(server?"Przy samochodzie":"Diagnosta",15,true);roleTitle.ForeColor=Color.White;roleTitle.Margin=new Padding(0,0,0,12);Ui.Add(side,roleTitle);
   var roleDescription=Ui.Label(server?"Ten komputer udostępnia interfejs podłączony do auta.":"Ten komputer korzysta ze zdalnego interfejsu.");roleDescription.MaximumSize=new Size(180,0);roleDescription.ForeColor=Color.FromArgb(179,196,211);roleDescription.Margin=new Padding(0,0,0,18);Ui.Add(side,roleDescription);
   changeRole.Text="Zmień rolę";Ui.Button(changeRole);changeRole.BackColor=Ui.Navy;changeRole.ForeColor=Color.White;changeRole.FlatAppearance.BorderColor=Color.FromArgb(67,87,107);changeRole.Margin=new Padding(0,0,0,36);changeRole.Click+=delegate{if(!busy&&!refreshing&&share==null&&attachment==null){ChangeRoleRequested=true;Close();}};Ui.Add(side,changeRole);
   var steps=Ui.Label(server?"01   Podłącz interfejs\n\n02   Udostępnij połączenie\n\n03   Przekaż kod diagnoście":"01   Odbierz kod sesji\n\n02   Połącz z samochodem\n\n03   Uruchom diagnostykę",10);steps.MaximumSize=new Size(180,0);steps.ForeColor=Color.FromArgb(179,196,211);Ui.Add(side,steps);
   var version=Ui.Label("USB / J2534 + ENET\nWersja 0.6.0 • prototyp",9);version.ForeColor=Color.FromArgb(139,161,182);version.Dock=DockStyle.Bottom;sidebar.Controls.Add(side);sidebar.Controls.Add(version);
   var viewport=new Panel{Dock=DockStyle.Fill,AutoScroll=true,Padding=new Padding(24,20,24,20),Margin=Padding.Empty};shell.Controls.Add(viewport,1,0);
   var root=Ui.Stack();root.Dock=DockStyle.Top;viewport.Controls.Add(root);
   var heading=Ui.Stack();heading.Margin=new Padding(0,0,0,16);Ui.Add(heading,Ui.Label(server?"Udostępnij swój interfejs":"Połącz się z samochodem",23,true));
   var lead=Ui.Label(server?"Wybierz połączenie. Po uruchomieniu przekaż kod diagnoście.":"Wklej kod otrzymany od osoby przy samochodzie.");lead.ForeColor=Ui.Muted;Ui.Add(heading,lead);Ui.Add(root,heading);

   var connection=Ui.Stack();
   var selection=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=2,RowCount=2,Margin=Padding.Empty};selection.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,42));selection.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,58));
   selection.Controls.Add(Ui.Label("Rodzaj połączenia",9),0,0);selection.Controls.Add(Ui.Label("Sieć RadminVPN",9),1,0);
   mode.DropDownStyle=ComboBoxStyle.DropDownList;mode.Dock=DockStyle.Top;mode.Margin=new Padding(0,0,12,10);mode.Items.AddRange(new object[]{"USB • interfejs J2534","ENET • przewód Ethernet"});mode.SelectedIndex=0;mode.Enabled=server;mode.AccessibleName="Rodzaj połączenia";
   vpn.DropDownStyle=ComboBoxStyle.DropDownList;vpn.Dock=DockStyle.Top;vpn.Margin=new Padding(0,0,0,10);vpn.AccessibleName="Adres RadminVPN";selection.Controls.Add(mode,0,1);selection.Controls.Add(vpn,1,1);Ui.Add(connection,selection);
   deviceLabel.AutoSize=true;deviceLabel.Font=new Font("Segoe UI",9);deviceLabel.Margin=new Padding(0,0,0,5);Ui.Add(connection,deviceLabel);
   var hardware=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=2,RowCount=1,Margin=Padding.Empty};hardware.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));hardware.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,110));
   equipment.DropDownStyle=ComboBoxStyle.DropDownList;equipment.Dock=DockStyle.Top;equipment.Margin=new Padding(0,4,12,0);equipment.AccessibleName="Interfejs USB lub karta sieciowa";
   deviceHint.Text="Interfejs USB pojawi się w Windows po połączeniu.";deviceHint.AutoSize=true;deviceHint.ForeColor=Ui.Muted;deviceHint.Dock=DockStyle.Fill;deviceHint.Margin=new Padding(0,6,0,0);
   refresh.Text="Odśwież";Ui.Button(refresh);refresh.Height=32;refresh.Dock=DockStyle.Top;refresh.Margin=Padding.Empty;refresh.Click+=async delegate{await RefreshEquipment();};hardware.Controls.Add(equipment,0,0);hardware.Controls.Add(deviceHint,0,0);hardware.Controls.Add(refresh,1,0);Ui.Add(connection,hardware);
   Ui.Add(root,Ui.Card("01  /  POŁĄCZENIE",connection));

   var invitation=Ui.Stack();var codeHint=Ui.Label(server?"Kod będzie dostępny po kliknięciu „Udostępnij interfejs”.":"Tryb USB lub ENET zostanie rozpoznany z kodu.",9);codeHint.ForeColor=Ui.Muted;Ui.Add(invitation,codeHint);
   var codeLayout=new TableLayoutPanel{Dock=DockStyle.Top,ColumnCount=2,RowCount=1,Height=72,Margin=Padding.Empty};codeLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));codeLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,126));
   code.Multiline=true;code.MaxLength=2048;code.ReadOnly=server;code.ScrollBars=ScrollBars.Vertical;code.Font=new Font("Consolas",9);code.Dock=DockStyle.Fill;code.BorderStyle=BorderStyle.FixedSingle;code.BackColor=Color.FromArgb(248,250,252);code.Margin=new Padding(0,0,12,0);code.AccessibleName=server?"Kod dla diagnosty":"Kod z komputera przy samochodzie";
   copy.Text=server?"Kopiuj kod":"Wklej kod";Ui.Button(copy);copy.Dock=DockStyle.Top;copy.Margin=Padding.Empty;copy.Click+=delegate{try{if(server){if(code.TextLength>0){Clipboard.SetText(code.Text);SetStatus("Kod skopiowany. Przekaż go diagnoście.");}}else if(Clipboard.ContainsText())code.Text=Clipboard.GetText().Trim();}catch(Exception e){Error(e);}};
   codeLayout.Controls.Add(code,0,0);codeLayout.Controls.Add(copy,1,0);Ui.Add(invitation,codeLayout);Ui.Add(root,Ui.Card("02  /  KOD SESJI",invitation));

   var state=Ui.Stack();state.BackColor=Color.FromArgb(227,240,240);state.Padding=new Padding(14,10,14,10);state.Margin=new Padding(0,0,0,14);
   statusTitle.Text="STATUS SESJI";statusTitle.AutoSize=true;statusTitle.Font=new Font("Segoe UI",8,FontStyle.Bold);statusTitle.ForeColor=Ui.Teal;statusTitle.Margin=new Padding(0,0,0,4);Ui.Add(state,statusTitle);
   status.AutoSize=true;status.MaximumSize=new Size(740,0);status.Text="Przygotowanie…";status.Margin=Padding.Empty;Ui.Add(state,status);state.SizeChanged+=delegate{status.MaximumSize=new Size(Math.Max(180,state.ClientSize.Width-state.Padding.Horizontal),0);};Ui.Add(root,state);
   var actions=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true,WrapContents=true,Margin=new Padding(0,0,0,14)};
   start.Text=server?"Udostępnij interfejs":"Połącz z samochodem";start.Width=230;Ui.Button(start,true);stop.Text=server?"Zakończ sesję":"Rozłącz";stop.Width=150;Ui.Button(stop);
   recover.Text="Zwolnij USB po awarii";recover.Width=205;Ui.Button(recover);recover.Click+=async delegate{await Recover();};
   start.Click+=async delegate{await StartSession();};stop.Click+=delegate{StopSession();};actions.Controls.Add(start);actions.Controls.Add(stop);actions.Controls.Add(recover);Ui.Add(root,actions);AcceptButton=start;

   var footer=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true,Margin=new Padding(0,0,0,10)};
   advanced.Text="Ustawienia USB";advanced.AutoSize=true;advanced.ForeColor=Ui.Muted;advanced.Margin=new Padding(0,5,16,5);advanced.CheckedChanged+=delegate{settings.Visible=advanced.Checked;};details.Text="Szczegóły sesji";details.AutoSize=true;details.ForeColor=Ui.Muted;details.Margin=new Padding(0,5,16,5);details.CheckedChanged+=delegate{log.Visible=details.Checked;};
   var help=new LinkLabel{Text="Instrukcja",AutoSize=true,Margin=new Padding(0,5,16,5),LinkColor=Ui.Teal,ActiveLinkColor=Ui.Ink};help.LinkClicked+=delegate{ShowHelp();};transfer.AutoSize=true;transfer.ForeColor=Ui.Muted;transfer.Margin=new Padding(0,5,0,5);
   footer.Controls.Add(advanced);footer.Controls.Add(details);footer.Controls.Add(help);footer.Controls.Add(transfer);Ui.Add(root,footer);
   settings.Text="Obsługa USB — wbudowana w AutoTunel";settings.Dock=DockStyle.Top;settings.Height=132;settings.Visible=false;settings.Padding=new Padding(12);settings.Margin=new Padding(0,0,0,12);
   var config=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=3};config.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));config.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,155));config.RowStyles.Add(new RowStyle(SizeType.Absolute,36));config.RowStyles.Add(new RowStyle(SizeType.Absolute,25));config.RowStyles.Add(new RowStyle(SizeType.Percent,100));
   string configError=null;try{tool.Text=new WindowsUsbSetupHost().FindTool(server);}catch(Exception e){configError=MessageOf(e);}
   tool.ReadOnly=true;tool.Dock=DockStyle.Fill;tool.Margin=new Padding(0,3,8,0);tool.AccessibleName="Lokalizacja obsługi USB";
   prepareUsb.Text="Przygotuj USB";prepareUsb.Dock=DockStyle.Fill;Ui.Button(prepareUsb);prepareUsb.Margin=Padding.Empty;prepareUsb.Click+=async delegate{await RefreshEquipment(true);};config.Controls.Add(tool,0,0);config.Controls.Add(prepareUsb,1,0);
   var configNote=Ui.Label("Wszystkie składniki USB są w tym EXE. AutoTunel przygotuje je automatycznie.",8);configNote.ForeColor=Ui.Muted;config.Controls.Add(configNote,0,1);config.SetColumnSpan(configNote,2);
   var licenses=new LinkLabel{Text="Licencje składników USB",AutoSize=true,LinkColor=Ui.Teal,Margin=new Padding(0,5,0,0)};licenses.LinkClicked+=delegate{ShowEmbeddedDocument("AutoTunel.Usb.Notices.txt","Licencje-USB.txt");};config.Controls.Add(licenses,0,2);config.SetColumnSpan(licenses,2);settings.Controls.Add(config);Ui.Add(root,settings);
   log.Dock=DockStyle.Top;log.Height=160;log.Multiline=true;log.ReadOnly=true;log.ScrollBars=ScrollBars.Both;log.WordWrap=false;log.Font=new Font("Consolas",9);log.BackColor=Ui.Navy;log.ForeColor=Color.FromArgb(196,219,225);log.BorderStyle=BorderStyle.None;log.Visible=false;log.AccessibleName="Dziennik sesji";Ui.Add(root,log);
   mode.SelectedIndexChanged+=async delegate{if(!busy){UpdateControls();await RefreshEquipment();}};
   code.TextChanged+=delegate{if(!server&&!busy){try{var invite=Invitation.Parse(code.Text);mode.SelectedIndex=invite.Mode=="USB"?0:1;SetStatus(usbRestartRequired&&invite.Mode=="USB"?new UsbRestartRequiredException().Message:"Kod gotowy. Tryb "+invite.Mode+" zostanie ustawiony automatycznie.");}catch(FormatException e){if(code.TextLength>0)SetStatus(e.Message);}UpdateControls();}};
   timer.Tick+=delegate{if(tunnel!=null)transfer.Text="Wysłano "+Interlocked.Read(ref tunnel.Sent)/1024+" KB  •  Odebrano "+Interlocked.Read(ref tunnel.Received)/1024+" KB";};timer.Start();
   Shown+=async delegate{if(configError!=null){SetStatus(configError);statusTitle.Text="SPRAWDŹ USTAWIENIA";advanced.Checked=true;UpdateControls();}else await RefreshEquipment();};
   FormClosing+=delegate(object sender,FormClosingEventArgs e){if(busy||refreshing){closing=true;e.Cancel=true;StopSession();SetStatus("Kończenie sesji i zwalnianie interfejsu…");}else timer.Dispose();};
   UpdateControls();
  }
  void ShowHelp(){ShowEmbeddedDocument("AutoTunel.Help.html","AutoTunel-0.6.html");}
  void ShowEmbeddedDocument(string resourceName,string fileName){
   try{using(var resource=typeof(MainForm).Assembly.GetManifestResourceStream(resourceName)){
    if(resource==null)throw new IOException("Nie znaleziono instrukcji w aplikacji.");
    string folder=Path.Combine(Platform.DataDir,"help");Directory.CreateDirectory(folder);string path=Path.Combine(folder,fileName);using(var file=File.Create(path))resource.CopyTo(file);Open(path);
   }}catch(Exception e){Error(e);}
  }
  static string MessageOf(Exception error){while(error is AggregateException&&error.InnerException!=null)error=error.InnerException;return error.Message;}
  void SetStatus(string text){if(!IsDisposed){status.Text=text;statusTitle.Text="STATUS SESJI";statusTitle.ForeColor=Ui.Teal;}}
  void Error(Exception error){string message=MessageOf(error);SetStatus(message);statusTitle.Text="WYMAGA UWAGI";statusTitle.ForeColor=Color.FromArgb(151,86,15);Log(message);}
  void Log(string message){
   if(IsDisposed||Disposing)return;
   if(InvokeRequired){try{BeginInvoke((Action)(()=>Log(message)));}catch(InvalidOperationException){}return;}
   if(log.TextLength>60000)log.Clear();log.AppendText(DateTime.Now.ToString("HH:mm:ss")+"  "+message+Environment.NewLine);
   if(message.StartsWith("OCZEKIWANIE",StringComparison.Ordinal)&&busy&&cancellation!=null&&!cancellation.IsCancellationRequested){code.Text=pendingCode;SetStatus("Gotowe. Przekaż kod diagnoście i pozostaw program otwarty.");UpdateControls();}
   if(server&&busy&&cancellation!=null&&!cancellation.IsCancellationRequested&&message.StartsWith("POŁĄCZONO",StringComparison.Ordinal))SetStatus("Diagnosta połączony. Interfejs jest udostępniany.");
  }
  void Open(string target){try{Process.Start(new ProcessStartInfo(target){UseShellExecute=true});}catch(Exception e){Error(e);}}
  UsbIpBackend NewBackend(){return new UsbIpBackend(new SystemCommandRunner(),server?tool.Text:"",server?"":tool.Text);}
  void UpdateControls(){
   bool idle=!busy&&!refreshing;
   changeRole.Enabled=idle&&share==null&&attachment==null;
   start.Enabled=idle&&share==null&&attachment==null&&!File.Exists(Journal)&&(!UsbMode||!usbRestartRequired);stop.Enabled=busy;refresh.Enabled=idle;prepareUsb.Enabled=idle&&!usbRestartRequired;
   mode.Enabled=server&&idle;vpn.Enabled=server&&idle;equipment.Enabled=idle&&(server||!UsbMode);advanced.Enabled=idle;
   copy.Enabled=server?busy&&code.TextLength>0:idle;code.ReadOnly=server||busy||refreshing;settings.Enabled=idle;
   recover.Visible=File.Exists(Journal)||share!=null&&!busy||attachment!=null&&!busy;recover.Enabled=idle;
   deviceLabel.Text=UsbMode?(server?"Interfejs USB":"USB z kodu"):(server?"Przewód ENET":"Karta TAP");
   equipment.Visible=server||!UsbMode;deviceHint.Visible=!server&&UsbMode;refresh.Visible=server||!UsbMode;
  }
  void ReportUsbSetup(string message){
   if(IsDisposed||Disposing)return;
   if(InvokeRequired){try{BeginInvoke((Action)(()=>ReportUsbSetup(message)));}catch(InvalidOperationException){}return;}
   Log(message);
   if(message.StartsWith("Przygotowywanie",StringComparison.Ordinal)||message.StartsWith("Instalowanie",StringComparison.Ordinal)||message.StartsWith("Obsługa USB",StringComparison.Ordinal))SetStatus(message);
  }
  async Task EnsureUsbReady(CancellationToken token){
   SetStatus("Sprawdzanie wbudowanej obsługi USB…");
   try{tool.Text=await Task.Run(()=>new UsbSetup(new WindowsUsbSetupHost()).EnsureReady(server,token,ReportUsbSetup));}
   catch(UsbRestartRequiredException){usbRestartRequired=true;throw;}
  }
  async Task RefreshEquipment(bool prepareClient=false){
   if(busy||refreshing)return;refreshing=true;UpdateControls();
   try{
    string previous=(equipment.SelectedItem as UsbIpDevice)?.InstanceId??(equipment.SelectedItem as AdapterInfo)?.Id;
    var selected=vpn.SelectedItem as VpnAddress;vpn.Items.Clear();foreach(var item in WindowsUsb.VpnAddresses())vpn.Items.Add(item);
    vpn.SelectedIndex=-1;for(int i=0;i<vpn.Items.Count;i++)if(((VpnAddress)vpn.Items[i]).Address.Equals(selected?.Address))vpn.SelectedIndex=i;
    if(vpn.SelectedIndex<0&&vpn.Items.Count==1)vpn.SelectedIndex=0;
    equipment.Items.Clear();
    if(UsbMode){if(server||prepareClient)await EnsureUsbReady(CancellationToken.None);
     else if(await Task.Run(()=>{var host=new WindowsUsbSetupHost();using(host.EnterSetup(CancellationToken.None))return host.RestartPending(false);})){usbRestartRequired=true;throw new UsbRestartRequiredException();}
     if(server){var engine=NewBackend();var devices=await Task.Run(()=>engine.Devices());foreach(var device in devices)equipment.Items.Add(device);
      var matches=devices.Where(d=>d.InstanceId==previous).ToList();if(matches.Count==0)matches=devices.Where(d=>(d.Description??"").IndexOf("Openport",StringComparison.OrdinalIgnoreCase)>=0||(d.Description??"").IndexOf("Tactrix",StringComparison.OrdinalIgnoreCase)>=0).ToList();
      if(matches.Count==1)equipment.SelectedItem=matches[0];else if(devices.Count==1)equipment.SelectedIndex=0;
     }
    }else{
     var adapters=AdapterInfo.List(!server);foreach(var adapter in adapters)equipment.Items.Add(adapter);
     equipment.SelectedIndex=-1;for(int i=0;i<equipment.Items.Count;i++)if(((AdapterInfo)equipment.Items[i]).Id==previous)equipment.SelectedIndex=i;
     if(equipment.SelectedIndex<0&&equipment.Items.Count==1)equipment.SelectedIndex=0;
    }
    SetStatus(UsbMode&&usbRestartRequired?new UsbRestartRequiredException().Message:vpn.Items.Count==0?"Uruchom RadminVPN i połącz oba komputery z tą samą siecią.":File.Exists(Journal)?"Pozostało USB z poprzedniej sesji. Kliknij Zwolnij USB po awarii.":"Gotowy. "+(server?"Wybierz interfejs i kliknij Udostępnij.":"Wklej kod z komputera przy samochodzie. Obsługa USB zostanie przygotowana automatycznie."));
   }catch(Exception e){Error(e);if(UsbMode)advanced.Checked=true;}
   finally{refreshing=false;UpdateControls();if(closing)Close();}
  }
  static Task Blocking(Action action){return Task.Factory.StartNew(action,CancellationToken.None,TaskCreationOptions.LongRunning,TaskScheduler.Default);}
  void StopSession(){if(cancellation!=null)cancellation.Cancel();tunnel?.Dispose();SetStatus("Zwalnianie interfejsu…");}
  async Task StartSession(){
   if(busy||refreshing||share!=null||attachment!=null)return;
   busy=true;cancellation=new CancellationTokenSource();var token=cancellation.Token;UpdateControls();X509Certificate2 certificate=null;sessionTask=null;
   string failure=null;
   try{
    if(File.Exists(Journal))throw new IOException("Najpierw zwolnij USB po poprzedniej sesji.");
    if(WindowsUsb.VpnAddresses().Count==0)throw new IOException("Uruchom RadminVPN i dołącz do sieci klienta.");
    Invitation invite;var address=vpn.SelectedItem as VpnAddress;
    if(server){
     if(address==null)throw new IOException("Wybierz swój adres RadminVPN.");
     if(UsbMode&&!(equipment.SelectedItem is UsbIpDevice))throw new IOException("Podłącz Openport i wybierz go na liście USB.");
     invite=new Invitation{Host=address.Address.ToString(),Port=SessionPort,Pin=new string('A',64),Key=Wire.Secret(),Mode=UsbMode?"USB":"LAN",UsbBusId=UsbMode?((UsbIpDevice)equipment.SelectedItem).BusId:""};
    }else {invite=Invitation.Parse(code.Text);mode.SelectedIndex=invite.Mode=="USB"?0:1;}
    invite.Validate();var adapter=equipment.SelectedItem as AdapterInfo;
    if(invite.Mode=="LAN"){
     if(adapter==null)throw new IOException(server?"Wybierz kartę połączoną przewodem z autem.":"Wybierz wirtualną kartę TAP-Windows6.");
     if(server){var nic=NetworkInterface.GetAllNetworkInterfaces().SingleOrDefault(n=>n.Id==adapter.Id);if(nic==null||nic.GetIPProperties().GatewayAddresses.Count>0)throw new IOException("Wybierz dedykowaną kartę ENET bez bramy. Internet pozostaw na drugiej karcie.");}
    }
    SetStatus("Przygotowanie interfejsu…");
    if(invite.Mode=="USB"){
     await EnsureUsbReady(token);backend=NewBackend();token.ThrowIfCancellationRequested();
     if(server){
      if(File.Exists(Journal))throw new IOException("Najpierw zwolnij USB po poprzedniej sesji.");
      var selected=equipment.SelectedItem as UsbIpDevice;
      share=await Task.Run(()=>backend.Share(selected));
      if(share.Owned){Directory.CreateDirectory(Platform.DataDir);File.WriteAllText(Journal,share.Device.PersistedGuid);}
      await Task.Run(()=>WindowsUsb.ProbeExport(invite.UsbBusId));token.ThrowIfCancellationRequested();
     }
    }
    token.ThrowIfCancellationRequested();
    if(server){certificate=await Task.Run(()=>Platform.Certificate());token.ThrowIfCancellationRequested();invite.Pin=Wire.Pin(certificate.RawData);pendingCode=invite.Encode();code.Clear();}
    var current=new Tunnel(server,invite.Mode,Log,0,3240,server?address.Address:null);tunnel=current;var cert=certificate;
    sessionTask=Blocking(()=>current.Run(invite,cert,()=>server?(IEthernet)new PcapAdapter(adapter.Id):new TapAdapter(adapter.Id)));
    if(!server){
     var deadline=DateTime.UtcNow.AddSeconds(30);SetStatus("Łączenie z komputerem przy samochodzie…");
     while(!current.Connected){token.ThrowIfCancellationRequested();if(sessionTask.IsCompleted){await sessionTask;throw new IOException("Nie utworzono połączenia.");}if(DateTime.UtcNow>deadline)throw new IOException("Przekroczono czas zestawiania połączenia.");await Task.Delay(50,token);}
     if(invite.Mode=="USB"){
      Directory.CreateDirectory(Platform.DataDir);File.WriteAllText(Journal,current.UsbPort+"|"+invite.UsbBusId);
      SetStatus("Podłączanie USB do Windows…");attachment=await Task.Run(()=>backend.Attach(current.UsbPort,invite.UsbBusId));token.ThrowIfCancellationRequested();
      SetStatus("USB podłączone do Windows. Sprawdź Openport w Xentry PassThru.");
     }else SetStatus("Tunel ENET połączony. Sprawdź adresację TAP i wykrywanie auta.");
    }
    if(!server&&attachment!=null){
     while(!sessionTask.IsCompleted){
      await Task.WhenAny(sessionTask,Task.Delay(2000,token));token.ThrowIfCancellationRequested();
      if(!sessionTask.IsCompleted&&!await Task.Run(()=>attachment.Present()))throw new IOException("Utracono interfejs USB. Sprawdź przewód i rozpocznij nową sesję.");
     }
    }
    await sessionTask;
   }catch(Exception e){if(e is UsbRestartRequiredException||!token.IsCancellationRequested){failure=MessageOf(e);Log(failure);}}
   finally{
    tunnel?.Dispose();if(sessionTask!=null)try{await sessionTask;}catch(Exception){}
    bool clean=await Cleanup();certificate?.Dispose();tunnel=null;pendingCode=null;if(server)code.Clear();cancellation.Dispose();cancellation=null;busy=false;
    UpdateControls();SetStatus(!clean?"Nie udało się zwolnić USB. Użyj przycisku zwalniania i sprawdź szczegóły.":failure??"Sesja zakończona. Interfejs został zwolniony.");if(closing)Close();
   }
  }
  async Task<bool> Cleanup(){
   bool clean=true;
   if(attachment!=null)try{await Task.Run(()=>attachment.Dispose());attachment=null;}catch(Exception e){clean=false;Log(MessageOf(e));}
   if(share!=null)try{await Task.Run(()=>share.Dispose());share=null;if(File.Exists(Journal))File.Delete(Journal);}catch(Exception e){clean=false;Log(MessageOf(e));}
   if(!server&&attachment==null&&File.Exists(Journal))try{await ReleaseClientJournal();}catch(Exception e){clean=false;Log(MessageOf(e));}
   return clean;
  }
  async Task ReleaseClientJournal(){
   string[] fields=File.ReadAllText(Journal).Trim().Split('|');int port;
   if(fields.Length!=2||!int.TryParse(fields[0],out port)||port<1024||port>65535||!UsbIpBackend.ValidBusId(fields[1]))throw new IOException("Uszkodzony zapis poprzedniej sesji USB. Sprawdź instrukcję odzyskiwania.");
   var engine=NewBackend();await Task.Run(()=>{engine.CheckTools(false);engine.ReleaseEndpoint(port,fields[1]);});File.Delete(Journal);
  }
  async Task Recover(){
   if(busy||refreshing)return;refreshing=true;UpdateControls();
   try{
    await EnsureUsbReady(CancellationToken.None);
    if(!await Cleanup())throw new IOException("Nie udało się zwolnić interfejsu. Sprawdź szczegóły.");
    if(server&&File.Exists(Journal)){string guid=File.ReadAllText(Journal).Trim();var engine=NewBackend();await Task.Run(()=>{engine.CheckTools(true);engine.Unshare(guid);});File.Delete(Journal);}
    SetStatus("USB zwolnione. Możesz rozpocząć nową sesję.");
   }catch(Exception e){Error(e);}finally{refreshing=false;UpdateControls();if(closing)Close();}
  }
 }
 static class Program {
  [STAThread] static void Main(){
   Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
   bool created;using(var mutex=new Mutex(true,"Local\\AutoTunel-MB",out created)){
    if(!created){MessageBox.Show("AutoTunel jest już uruchomiony.","AutoTunel MB");return;}
    try{
     while(true){
      bool server;using(var picker=new RolePicker()){if(picker.ShowDialog()!=DialogResult.OK)return;server=picker.Server;}
      bool roleCreated;using(var roleMutex=new Mutex(true,"Local\\AutoTunel-MB-"+(server?"Server":"Client"),out roleCreated)){
       if(!roleCreated){MessageBox.Show("Ta rola jest już uruchomiona w innym oknie AutoTunel.","AutoTunel MB");continue;}
       try{using(var form=new MainForm(server)){Application.Run(form);if(!form.ChangeRoleRequested)return;}}
       finally{roleMutex.ReleaseMutex();}
      }
     }
    }finally{mutex.ReleaseMutex();}
   }
  }
 }
}
