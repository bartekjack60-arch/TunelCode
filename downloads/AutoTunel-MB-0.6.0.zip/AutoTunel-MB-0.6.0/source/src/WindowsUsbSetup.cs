using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using System.Security.AccessControl;
using System.Security.Principal;
using System.ServiceProcess;
using System.Threading;
using Microsoft.Win32;

namespace AutoTunel {
 public sealed class WindowsUsbSetupHost:IUsbSetupHost {
  const string RegistryPath=@"SOFTWARE\AutoTunel-MB\UsbSetup";
  sealed class HeldMutex:IDisposable {
   readonly Mutex mutex;
   public HeldMutex(Mutex value){mutex=value;}
   public void Dispose(){mutex.ReleaseMutex();mutex.Dispose();}
  }
  public IDisposable EnterSetup(CancellationToken token){
   var mutex=new Mutex(false,@"Global\AutoTunel-MB-USB-Setup");
   try{
    int result;
    try{result=WaitHandle.WaitAny(new WaitHandle[]{mutex,token.WaitHandle},TimeSpan.FromMinutes(10));}
    catch(AbandonedMutexException){result=0;}
    if(result==1)throw new OperationCanceledException(token);
    if(result!=0)throw new IOException("Inne okno przygotowuje USB. Poczekaj na zakończenie i spróbuj ponownie.");
    return new HeldMutex(mutex);
   }catch{mutex.Dispose();throw;}
  }
  static RegistryKey Machine(){return RegistryKey.OpenBaseKey(RegistryHive.LocalMachine,RegistryView.Registry64);}
  static string Marker(bool server){return server?"ServerRestart":"ClientRestart";}
  static string BootStamp(){
   using(var query=new ManagementObjectSearcher("SELECT LastBootUpTime FROM Win32_OperatingSystem"))
   using(var results=query.Get()){
    foreach(ManagementObject item in results)using(item){
     var value=item["LastBootUpTime"] as string;
     if(!string.IsNullOrEmpty(value))return ManagementDateTimeConverter.ToDateTime(value).ToUniversalTime().Ticks.ToString(CultureInfo.InvariantCulture);
    }
   }
   throw new IOException("Windows nie udostępnił informacji o ostatnim uruchomieniu. Nie można potwierdzić zakończenia przygotowania USB.");
  }
  public bool RestartPending(bool server){
   using(var machine=Machine())using(var key=machine.OpenSubKey(RegistryPath,true)){
    var value=key?.GetValue(Marker(server));if(value==null)return false;
    if(!(value is string))throw new IOException("Uszkodzony zapis przygotowania USB w Windows.");
    if((string)value==BootStamp())return true;
    key.DeleteValue(Marker(server));return false;
   }
  }
  public void MarkRestart(bool server){using(var machine=Machine())using(var key=machine.CreateSubKey(RegistryPath))key.SetValue(Marker(server),BootStamp(),RegistryValueKind.String);}
  public void ClearRestart(bool server){using(var machine=Machine())using(var key=machine.OpenSubKey(RegistryPath,true))key?.DeleteValue(Marker(server),false);}
  public string FindTool(bool server){
   string known=WindowsUsb.FindTool(server);if(File.Exists(known))return known;
   using(var machine=Machine())using(var key=machine.OpenSubKey(server?@"SOFTWARE\usbipd-win":@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{199505b0-b93d-4521-a8c7-897818e0205a}_is1")){
    string folder=key?.GetValue(server?"APPLICATIONFOLDER":"InstallLocation") as string;
    if(!string.IsNullOrWhiteSpace(folder))return Path.Combine(folder,server?"usbipd.exe":"usbip.exe");
   }
   return known;
  }
  public bool ToolExists(string path){return File.Exists(path);}
  public void CheckReady(bool server,string path){
   var engine=new UsbIpBackend(new SystemCommandRunner(),path,path);engine.CheckTools(server);
   if(server){
    using(var service=new ServiceController("usbipd")){
     try{
      if(service.Status==ServiceControllerStatus.Stopped)service.Start();
      service.WaitForStatus(ServiceControllerStatus.Running,TimeSpan.FromSeconds(30));
     }catch(Exception error)when(error is InvalidOperationException||error is System.ServiceProcess.TimeoutException||error is System.ComponentModel.Win32Exception){
      throw new IOException("Windows nie uruchomił obsługi USB. Uruchom ponownie komputer, a następnie otwórz AutoTunel. "+error.Message,error);
     }
    }
    engine.Devices();
   }
  }
  public string Stage(UsbPackage package){
   // A new, unpredictable directory with an explicit ACL, outside user-writable TEMP.
   string folder=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),"AutoTunel-MB-USB-"+Guid.NewGuid().ToString("N"));
   var security=new DirectorySecurity();security.SetAccessRuleProtection(true,false);
   foreach(var sid in new[]{WellKnownSidType.BuiltinAdministratorsSid,WellKnownSidType.LocalSystemSid})
    security.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(sid,null),FileSystemRights.FullControl,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));
   Directory.CreateDirectory(folder,security);
   string target=Path.Combine(folder,package.FileName);
   try{using(var input=typeof(WindowsUsbSetupHost).Assembly.GetManifestResourceStream(package.ResourceName))UsbPayload.WriteVerified(input,target,package.Sha256);}
   catch{Directory.Delete(folder,true);throw;}
   return target;
  }
  public void DiscardStage(string installer){
   File.Delete(installer);string folder=Path.GetDirectoryName(installer);
   if(!Directory.EnumerateFileSystemEntries(folder).Any())Directory.Delete(folder);
  }
  public int Install(UsbPackage package,string installer,Action<string> progress){
   string folder=Path.GetDirectoryName(installer),log=Path.Combine(folder,"install.log");
   string executable=package.Server?Path.Combine(Environment.SystemDirectory,"msiexec.exe"):installer;
   var arguments=UsbInstallCommand.Arguments(package,installer,log);
   progress("Dziennik przygotowania USB: "+log);
   bool exited=false;
   try{
    using(var process=Process.Start(new ProcessStartInfo(executable,string.Join(" ",arguments.Select(SystemCommandRunner.QuoteArgument))){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=folder})){
     if(process==null)throw new IOException("Windows nie uruchomił przygotowania USB.");
     if(!process.WaitForExit(15*60*1000))throw new IOException("Przygotowanie USB nadal trwa. Dziennik: "+log+". Poczekaj na zakończenie pracy Windows; nie uruchamiaj drugiej instalacji.");
     exited=true;progress("Przygotowanie USB: kod "+process.ExitCode+". Dziennik: "+log);return process.ExitCode;
    }
   }finally{
    if(exited)try{File.Delete(installer);}catch(IOException){progress("Plik instalacyjny pozostał w "+folder);}
   }
  }
 }
}
