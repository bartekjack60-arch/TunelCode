$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
 & dotnet build AutoTunel.csproj -c Release -o 'dist/AutoTunel'
 if ($LASTEXITCODE -ne 0) { throw 'Kompilacja AutoTunel nie powiodła się.' }
 & dotnet run --project tests/Tests.csproj -c Release
 if ($LASTEXITCODE -ne 0) { throw 'Testy nie powiodły się.' }
} finally { Pop-Location }
