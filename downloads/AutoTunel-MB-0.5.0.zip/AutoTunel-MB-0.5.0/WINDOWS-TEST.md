# Pierwsza próba na Windows — Openport 2.0 / Xentry PassThru

Ten etap wymaga dwóch rzeczywistych komputerów Windows 10/11 x64 i Openporta.
Testy w Linux nie potwierdzają zgodności sterownika ani działania Xentry.
Punktem odniesienia jest podany przez użytkownika działający zestaw
Xentry PassThru + Openport 2.0 + VirtualHere.

1. Skopiuj sam `AutoTunel.exe` wersji 0.5 do pustego katalogu na obu
   komputerach. Sprawdź start bez `.exe.config` i bez zewnętrznego pliku
   instrukcji; przycisk instrukcji powinien otworzyć wbudowaną pomoc.
2. Połącz oba komputery przez RadminVPN. W tym samym programie wybierz rolę:
   **Przy samochodzie** (Server) u klienta, **Diagnosta** (Client) u Ciebie.
   Sprawdź czy opisy, działania i wskazywane narzędzie USB odpowiadają roli.
3. Jednorazowo zainstaluj oficjalne komponenty x64 z linków w ustawieniach:
   usbipd-win **5.3.0** przy samochodzie; usbip-win2 **0.9.8.1** u diagnosty.
   Użyj oficjalnych podpisanych wydań; prototyp nie wymaga włączania trybu
   testowego sterowników ani wyłączania kontroli podpisów Windows.
4. Na komputerze diagnosty zachowaj właściwy sterownik swojego Openporta.
   Na czas próby zwolnij Openporta w VirtualHere i innych aplikacjach.
5. W Server wybierz USB i właściwy Openport. Przy kilku urządzeniach sprawdź
   wybór. Kliknij **Udostępnij interfejs**. Kod powinien pojawić się dopiero
   po przygotowaniu eksportu USB i uruchomieniu nasłuchu.
6. Przy założonej wyłączonej Zaporze Windows sprawdź, że aplikacja nie żąda
   włączenia zapory ani konfiguracji reguł. Właściwa sesja używa TCP 24832.
   Usługa USB/IP może być osiągalna bezpośrednio na TCP 3240; kod AutoTunel
   nie zabezpiecza tego bezpośredniego portu. Test wykonuj w zaufanej sieci.
7. Przekaż kod prywatnie, wklej w Client i kliknij **Połącz z samochodem**.
   Kod zawiera sekret sesji; nie dodawaj go do raportów.
8. Po komunikacie o podłączeniu USB sprawdź Menedżer urządzeń na komputerze
   diagnosty. Sprawdź sterownik Openporta i stan urządzenia.
9. Uruchom Xentry PassThru: sprawdź wybór interfejsu, identyfikację pojazdu
   i odczyt. Zanotuj wersję Xentry, Windows i sterownika Openporta oraz wyniki
   tych trzech kroków. Ten test nie obejmuje programowania ECU.
10. Zakończ diagnostykę, kliknij **Rozłącz**, a następnie sprawdź zwolnienie
    interfejsu i możliwość ponownego udostępnienia z nowym kodem.
11. Osobno sprawdź odpięcie USB i utratę RadminVPN podczas odczytu.
    Oczekiwane jest zgłoszenie utraty interfejsu i zakończenie sesji;
    wznowienie wymaga nowego kodu. Nie ma automatycznego odtwarzania operacji.

Dodatkowo sprawdź interfejs w skalowaniu Windows 100%, 125%, 150% i 200%:
wybór roli, główny przycisk, kod, ustawienia i szczegóły muszą być czytelne
oraz osiągalne po przewinięciu w małym oknie. Ustaw ścieżkę narzędzia w jednej
roli, zamknij program, uruchom go w drugiej roli i upewnij się, że ustawienia
pierwszej roli są zachowane. Dla aktualizacji z wersji 0.4 sprawdź migrację
wcześniej zapisanych ścieżek.

Jeżeli etap nie przejdzie, podaj numer kroku i komunikat ze Szczegółów.
Sprawdzenie z rzeczywistym sprzętem jest warunkiem oceny prototypu.

## Odzyskiwanie

Program zapamiętuje własne udostępnienie według GUID, a własne podłączenie
według lokalnego portu i identyfikatora USB. Po awarii użyj **Zwolnij USB po
awarii**. Dzienniki odzyskiwania są w `%LOCALAPPDATA%\AutoTunel-MB`.
Kodów sesji i kluczy tam nie zapisujemy.

Jeżeli brakuje narzędzia USB/IP, najpierw zainstaluj właściwą wersję lub wskaż
ją w ustawieniach. Nie używaj poleceń odłączających wszystkie urządzenia USB.
W razie uszkodzonego zapisu odzyskiwania sprawdź `usbipd state` przy samochodzie
lub `usbip port` u diagnosty i zwolnij tylko urządzenie należące do tej sesji.

## ENET i dalsze urządzenia

Tryb ENET korzysta z dotychczasowego tunelu L2: Npcap przy samochodzie,
TAP-Windows6 u diagnosty. Nie emuluje J2534. Wymaga osobnego sprawdzenia
sterowników, adresacji TAP i obsługi ENET/DoIP w programie diagnostycznym.
SM2/SM3 Pro, Launch, VCX SE, DTS Monaco i Vediamo nie zostały sprawdzone
z tą aplikacją.
