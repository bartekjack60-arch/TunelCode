# AutoTunel MB 0.5 — jeden program do USB i ENET

Prototyp Windows do zdalnego korzystania z interfejsu przy samochodzie.
Pierwszy cel: **Xentry PassThru + Openport 2.0 + Windows 10/11 x64**.
Nie korzysta z VirtualHere. Obsługę fizycznego i wirtualnego USB zapewniają
oddzielnie instalowane, otwarte komponenty USB/IP; aplikacja steruje sesją.

Na obu komputerach uruchamia się ten sam **`AutoTunel.exe`**. Przy starcie
wybierz rolę:

| Komputer | Rola | Zadanie |
|---|---|---|
| U klienta przy samochodzie | **Przy samochodzie** (Server) | Udostępnia wybrany przewód USB lub ENET |
| U Ciebie, przy diagnostyce | **Diagnosta** (Client) | Podłącza zdalny interfejs do Twojego komputera |

Instrukcja jest wbudowana w EXE. Do przeniesienia samej aplikacji wystarcza
jeden plik, bez pliku `.exe.config`. Zewnętrzne sterowniki USB/IP i środowisko
.NET Framework nadal instaluje się na każdym komputerze.

## Pierwsze uruchomienie USB

1. Skopiuj `AutoTunel.exe` na oba komputery lub rozpakuj ZIP z dokumentacją.
2. Połącz komputery przez RadminVPN. Uruchom aplikację i wybierz właściwą
   rolę: **Przy samochodzie** u klienta, **Diagnosta** u Ciebie.
   Program wymaga uprawnień administratora.
3. W ustawieniach USB są linki do jednorazowej instalacji:
   - Server: [usbipd-win 5.3.0](https://github.com/dorssel/usbipd-win/releases/tag/v5.3.0), instalator x64.
   - Client: [usbip-win2 0.9.8.1](https://github.com/vadimgrn/usbip-win2/releases/tag/v.0.9.8.1), podpisany instalator x64.
   Sterowniki tych projektów nie są dołączone do tej paczki.
4. U diagnosty zainstaluj właściwy sterownik swojego Openporta. Zwolnij go
   w VirtualHere i innych aplikacjach przed rozpoczęciem próby.
5. W roli **Przy samochodzie** wybierz USB i Openport, kliknij **Udostępnij interfejs**.
   Pojedynczy rozpoznany Openport i adres RadminVPN są wybierane automatycznie.
   Jeśli jest kilka możliwości, wybierz właściwą.
6. Gdy pojawi się kod, przekaż go prywatnie diagnoście.
7. W roli **Diagnosta** kliknij **Wklej kod**, następnie **Połącz z samochodem**.
   Tryb USB i urządzenie wynikają z kodu; podłączenie wykonuje się automatycznie.
8. Sprawdź stan urządzenia w Windows, potem wykrycie i odczyt w Xentry.
   Po zakończeniu pracy kliknij **Rozłącz**.

Szczegółowy przebieg próby i oczekiwane wyniki: [WINDOWS-TEST.md](WINDOWS-TEST.md).
Oprogramowanie wymaga .NET Framework 4.8; użytkownik gotowego EXE nie potrzebuje
.NET SDK, Pythona ani WSL. Plik EXE prototypu nie ma podpisu wydawcy.

## Ustawienia

Ścieżki obu narzędzi USB/IP są przechowywane we wspólnym pliku ustawień
w `%LOCALAPPDATA%\AutoTunel-MB\settings.json`. Aplikacja przejmuje zapisane wcześniej
ścieżki z wersji 0.4. Ustawienia są lokalne dla użytkownika Windows i nie
są zaszyte w pliku EXE. Zmiana pliku programu nie usuwa ustawień. Jeśli zapis jest uszkodzony, aplikacja
zgłasza problem i zachowuje plik. Zachowaj jego kopię, zmień nazwę
`settings.json` i ponownie wskaż narzędzia w ustawieniach USB.

Zapisy odzyskiwania po awarii są oddzielnymi plikami w tym samym katalogu;
służą do zwolnienia tylko własnego urządzenia USB. Kodów i sekretów sesji
nie zapisuje się w konfiguracji.

## Co robi aplikacja

- Rozpoznaje aktywną kartę RadminVPN i na niej uruchamia sesję Server.
- Odczytuje rzeczywiste urządzenia przez `usbipd state`, sprawdza wersje narzędzi
  i obecność sterownika klienta.
- Udostępnia wybrane USB, potwierdza eksport odpowiedzią USB/IP i generuje kod
  dopiero po uruchomieniu nasłuchu.
- Kod AMB4 zawiera adres, tryb, identyfikator USB, pin certyfikatu i sekret
  sesji. Nie publikuj kodu. Wersje aplikacji sprzed 0.4 nie są zgodne z AMB4.
- Przesyła dane USB/IP przez własną sesję TLS 1.2. Kontrola importu blokuje
  żądania dostępu do urządzenia innego niż wybrane oraz listowanie innych USB.
- Wywołuje klienta USB/IP z `--once`, potwierdza lokalny port urządzenia
  i sprawdza jego obecność podczas sesji. Nie ponawia automatycznie podłączenia.
- Zwalnia własne podłączenie i własne udostępnienie; zachowuje stan urządzeń
  udostępnionych wcześniej przez użytkownika.
- Udostępnia przycisk odzyskiwania po awarii; zapisuje lokalnie identyfikatory
  potrzebne do zwolnienia własnego USB, bez kluczy i kodów sesji.

## Zapora i sieć

Sesja aplikacji używa TCP 24832 na wybranej karcie RadminVPN.
Nie wymaga publicznego adresu ani przekierowania portu na routerze.
AutoTunel łączy się lokalnie z USB/IP na porcie 3240 przy samochodzie; klient sterownika łączy
się z losowym portem loopback u diagnosty. Te połączenia przenosi tunel TLS.

Wersja 0.5 jest przygotowana do pracy przy wyłączonej Zaporze Windows:
nie sprawdza jej stanu, nie tworzy reguł, nie włącza ani nie wyłącza zapory.
Nie wymaga uruchamiania skryptu konfiguracji zapory. Reguły pozostawione
przez wcześniejsze wersje nie są zmieniane.

Usługa usbipd-win nasłuchuje również bezpośrednio na TCP 3240 na interfejsach
sieciowych. Przy wyłączonej zaporze inne komputery mające dostęp do tego portu
mogą korzystać z udostępnionego USB z pominięciem kodu i TLS AutoTunel.
Ta wersja wymaga zaufanej sieci; sam RadminVPN nie blokuje dostępu przez inne
karty sieciowe. Nie przekierowuj portu 3240 na routerze.

## ENET

Zachowano tunel Ethernet L2: dedykowana karta i Npcap x64 przy samochodzie,
TAP-Windows6 (`tap0901`) u diagnosty. Po stronie auta aplikacja odrzuca kartę
z bramą, żeby nie przejąć połączenia internetowego. Client rozpoznaje tryb z kodu.

Ramki Ethernet, ARP i broadcast przechodzą bez ręcznego mostkowania. Adresacja
TAP wymaga jeszcze przygotowania dla danej sieci auta; aplikacja nie zmienia
jej automatycznie. Ten tryb nie zamienia ENET w J2534. Wymaga programu
obsługującego odpowiednią komunikację Ethernet/DoIP.

## Stan weryfikacji

W Linux można sprawdzić kompilację jednego EXE dla .NET Framework 4.8 x64 oraz testy
transportu, USB/IP, obsługi narzędzi i zwalniania zasobów. Raport: `TESTY.txt`.
Testy CLI używają kontrolowanych odpowiedzi narzędzi, a transportu — prawdziwych
lokalnych TCP/TLS z symulowanymi urządzeniami. Nie jest to test fizycznego USB.

**Nie uruchomiono GUI, sterowników USB/IP ani Xentry na Windows.** Zgodność
Openporta (w tym klona), SM2/SM3 Pro, Launch, VCX SE, DTS Monaco i Vediamo
pozostaje niepotwierdzona. Programowanie ECU wymaga osobnej oceny po próbach
sprzętowych; ten prototyp służy najpierw do identyfikacji i odczytu.

## Kod

Źródła: `source/src`. Budowanie: `source/BUILD.ps1` na Windows lub
`tools/build.sh` na Linux z .NET SDK 8. Testy to program konsolowy,
nie projekt uruchamiany przez `dotnet test`. Szczegóły: `DEVELOPMENT.md`.
