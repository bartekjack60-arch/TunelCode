# Rozwój AutoTunel MB 0.4

Projekt pochodzi z paczki 0.2, a prototyp 0.4 zastępuje integrację VirtualHere
obsługą otwartych narzędzi USB/IP. Opublikowanego środowiska nie modyfikowano
ani nie publikowano ponownie podczas tej implementacji.

## Budowanie

Sprawdzone narzędzia: .NET SDK 8.0.427, .NET Framework 4.8 reference assemblies
z NuGet (Microsoft.NETFramework.ReferenceAssemblies 1.0.3), net8.0 do testów.
W środowisku chmurowym przed uruchomieniem poleceń w nowej powłoce:

```bash
export DOTNET_ROOT=/workspace/.tools/dotnet-8
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_CLI_HOME=/workspace/.cache/dotnet-cli
export NUGET_PACKAGES=/workspace/.cache/nuget/packages
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
cd /workspace/TunelCode
bash tools/build.sh
```

Na Windows z .NET SDK 8: `powershell -File source/BUILD.ps1`.
Użytkownik gotowej paczki potrzebuje .NET Framework 4.8, nie SDK.

Zestaw testów używa osobnych wątków dla blokujących pętli I/O. Nie wymaga już
obejścia `ThreadPoolMinThreads=32` stosowanego podczas importu wersji 0.2.
Można uruchomić wybrany test: `dotnet run --project source/tests/Tests.csproj
-c Release -- "USB gate"`. Brak dopasowanych testów kończy się błędem.

## Architektura

- `MainForm.cs`: role, wybór urządzenia, gotowość, sesja, anulowanie i odzyskiwanie.
- `UsbIp.cs`: JSON/CLI usbipd 5.3.0 i usbip-win2 0.9.8.1, kontrola importu
  wybranego urządzenia, odczyt odpowiedzi protokołu, własność podłączeń.
- `WindowsUsb.cs`: natywny runner, wykrywanie RadminVPN, reguły zapory,
  wykrywanie narzędzi i lokalny test eksportu USB/IP.
- `Tunnel.cs`: jedna autoryzowana sesja TLS i kanały USB lub ramki Ethernet.
  Nasłuch sesji w GUI jest przypięty do wybranego adresu RadminVPN; port
  klienta USB/IP jest dynamiczny i dostępny tylko przez loopback.
- `Wire.cs`: ograniczone ramki i kod AMB4 z trybem oraz identyfikatorem USB.
- `Adapters.cs`: Npcap przy samochodzie, TAP u diagnosty.
- `Platform.cs`: uruchamianie PowerShell i certyfikat Windows użytkownika.

Transport USB to USB/IP przez TLS; testy echo nie potwierdzają działania
sterownika USB ani funkcji J2534. Odpowiedzi CLI w testach backendu są
kontrolowanymi atrapami, opartymi na źródłach przypiętych wersji.

## Umowy z komponentami

USB/IP: wersja protokołu 0x0111. Pierwsze 40 bajtów kanału musi być
OP_REQ_IMPORT (0x8003) dla dokładnie wskazanego BusId. Obsługiwane są nagłówki
podzielone między ramki. OP_REQ_DEVLIST jest używany tylko lokalnie przy
sprawdzaniu gotowości serwera, przed udostępnieniem kodu.

Podstawy zweryfikowano w źródłach upstream:

- https://github.com/dorssel/usbipd-win/tree/v5.3.0
- https://github.com/vadimgrn/usbip-win2/tree/v.0.9.8.1

Stan JSON: `Devices`, `BusId`, `InstanceId`, `Description`, `PersistedGuid`,
`ClientIPAddress`. Cofanie własnego udostępnienia używa GUID, nie numeru
magistrali, który może zostać ponownie użyty po odpięciu USB.
Klient: `--tcp-port PORT attach --remote 127.0.0.1 --bus-id BUS --terse --once`.
Podłączenie potwierdza `usbip port`; odłączenie dotyczy tylko własnego portu.

## Pakowanie

Po udanym budowaniu i testach:

```bash
python3 tools/package.py --output /workspace/artifacts/AutoTunel-MB-0.4.0-USBIP.zip
```

Pakowanie odświeża EXE i `.exe.config` w Client/Server, kopiuje instrukcję,
przelicza `SHA256SUMS.txt` i tworzy ZIP z kodem. Nie dołącza instalatorów ani
sterowników zewnętrznych. `bin`, `obj`, `dist` nie trafiają do paczki.
Bieżący raport testów należy odświeżyć przed pakowaniem.

## Weryfikacja zewnętrzna

Kompilacja i testy w Linux nie zastępują testów Windows GUI, podpisanych
sterowników, skuteczności zapory w danej polityce Windows, RadminVPN,
Openporta i Xentry. Procedura jest w `WINDOWS-TEST.md`. Nie pomijaj tego etapu
przy ocenie zgodności sprzętu ani gotowości do kodowania/programowania.
