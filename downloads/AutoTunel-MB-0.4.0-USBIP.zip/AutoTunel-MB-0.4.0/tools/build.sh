#!/usr/bin/env bash
set -euo pipefail
repo_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_dir/source"
dotnet restore AutoTunel.csproj --disable-parallel
dotnet restore tests/Tests.csproj --disable-parallel
for role in Client Server; do
  dotnet build AutoTunel.csproj --no-restore -c Release -p:Role="$role" -o "dist/$role" -maxcpucount:2
done
dotnet build tests/Tests.csproj --no-restore -c Release -maxcpucount:2
dotnet run --project tests/Tests.csproj --no-build --no-restore -c Release
