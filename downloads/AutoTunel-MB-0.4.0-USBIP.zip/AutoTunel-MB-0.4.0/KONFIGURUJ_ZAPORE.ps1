# Uruchom jako administrator. Server konfiguruje reguły przy rozpoczęciu sesji.
param([switch]$Remove)
$ErrorActionPreference = 'Stop'
if (!$Remove) {
    Write-Host 'Uruchom AutoTunel-Server.exe przy samochodzie i kliknij Udostępnij.'
    Write-Host 'Program ustawi reguły dla wybranej karty RadminVPN.'
    Write-Host 'Aby usunąć tylko reguły AutoTunel, zamknij Server i użyj -Remove.'
    exit
}
if (Get-Process -Name 'AutoTunel-Server' -ErrorAction SilentlyContinue) {
    throw 'Zakończ sesję i zamknij AutoTunel Server przed usuwaniem reguł.'
}
foreach ($name in @('AutoTunel-Session', 'AutoTunel-USBIP-LocalOnly')) {
    Get-NetFirewallRule -Name $name -ErrorAction SilentlyContinue | Remove-NetFirewallRule
}
Write-Host 'Usunięto własne reguły AutoTunel. Pozostałe reguły zapory pozostają bez zmian.'
