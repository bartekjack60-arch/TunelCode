using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace AutoTunel {
 public sealed class MainForm:Form {
#if Server
  readonly bool server=true;
#else
  readonly bool server=false;
#endif
  readonly ComboBox mode=new ComboBox(),vpn=new ComboBox(),equipment=new ComboBox();
  readonly TextBox code=new TextBox(),tool=new TextBox(),log=new TextBox();
  readonly Button start=new Button(),stop=new Button(),refresh=new Button(),copy=new Button(),recover=new Button();
  readonly Label status=new Label(),deviceLabel=new Label(),transfer=new Label();
  readonly GroupBox settings=new GroupBox();readonly CheckBox details=new CheckBox(),advanced=new CheckBox();
  readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer{Interval=500};
  Tunnel tunnel;UsbIpBackend backend;SharedUsb share;UsbAttachment attachment;
  CancellationTokenSource cancellation;Task sessionTask;bool busy,refreshing,closing;string pendingCode;
  const int SessionPort=24832;
  bool UsbMode{get{return mode.SelectedIndex==0;}}
  string Journal{get{return Path.Combine(Platform.DataDir,server?"owned-usb-share.txt":"owned-usb-client.txt");}}

  public MainForm(){
   Text="AutoTunel MB 0.4 • "+(server?"Server przy samochodzie":"Client diagnosty");
   Size=new Size(900,780);MinimumSize=new Size(820,720);StartPosition=FormStartPosition.CenterScreen;
   AutoScaleMode=AutoScaleMode.Dpi;Font=new Font("Segoe UI",10);BackColor=Color.FromArgb(243,246,250);
   var root=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=10,Padding=new Padding(20),AutoScroll=true};Controls.Add(root);
   foreach(int h in new[]{78,48,42,138,74,48,62,0,0,34})root.RowStyles.Add(new RowStyle(h==0?SizeType.AutoSize:SizeType.Absolute,h));
   root.RowStyles[8]=new RowStyle(SizeType.Percent,100);
   var header=new Panel{Dock=DockStyle.Fill,BackColor=Color.FromArgb(24,38,59),Padding=new Padding(12)};
   header.Controls.Add(new Label{Text="AutoTunel MB",Font=new Font("Segoe UI",23,FontStyle.Bold),ForeColor=Color.White,Dock=DockStyle.Top,Height=42});
   header.Controls.Add(new Label{Text=server?"SERVER • komputer klienta przy samochodzie":"CLIENT • Twój komputer diagnostyczny",ForeColor=Color.LightSteelBlue,Dock=DockStyle.Bottom,Height=24});root.Controls.Add(header,0,0);
   root.Controls.Add(new Label{Text=server?"1. Podłącz interfejs do auta.   2. Kliknij Udostępnij.   3. Przekaż kod diagnoście.":"1. Wklej kod z komputera przy samochodzie.   2. Kliknij Połącz.   3. Uruchom diagnostykę.",Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft},0,1);
   var selection=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false};
   mode.DropDownStyle=ComboBoxStyle.DropDownList;mode.Width=240;mode.Items.AddRange(new object[]{"USB • interfejs J2534","ENET • przewód Ethernet"});mode.SelectedIndex=0;mode.Enabled=server;
   vpn.DropDownStyle=ComboBoxStyle.DropDownList;vpn.Width=480;selection.Controls.Add(mode);selection.Controls.Add(vpn);root.Controls.Add(selection,0,2);
   var invitation=new GroupBox{Text=server?"Kod dla diagnosty":"Kod z programu Server",Dock=DockStyle.Fill,Padding=new Padding(10)};
   var codeLayout=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2};codeLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));codeLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,135));
   code.Multiline=true;code.ReadOnly=server;code.ScrollBars=ScrollBars.Vertical;code.Font=new Font("Consolas",9);code.Dock=DockStyle.Fill;
   copy.Text=server?"Kopiuj kod":"Wklej kod";copy.Dock=DockStyle.Top;copy.Height=36;copy.Click+=delegate{try{if(server){if(code.TextLength>0)Clipboard.SetText(code.Text);}else if(Clipboard.ContainsText())code.Text=Clipboard.GetText().Trim();}catch(Exception e){Error(e);}};
   codeLayout.Controls.Add(code,0,0);codeLayout.Controls.Add(copy,1,0);invitation.Controls.Add(codeLayout);root.Controls.Add(invitation,0,3);
   var hardware=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=3};hardware.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,135));hardware.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));hardware.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,110));
   deviceLabel.Dock=DockStyle.Fill;deviceLabel.TextAlign=ContentAlignment.MiddleLeft;
   equipment.DropDownStyle=ComboBoxStyle.DropDownList;equipment.Dock=DockStyle.Top;equipment.Margin=new Padding(3,16,3,3);
   refresh.Text="Odśwież";refresh.Dock=DockStyle.Top;refresh.Height=34;refresh.Margin=new Padding(3,13,3,3);refresh.Click+=async delegate{await RefreshEquipment();};
   hardware.Controls.Add(deviceLabel);hardware.Controls.Add(equipment);hardware.Controls.Add(refresh);root.Controls.Add(hardware,0,4);
   var actions=new FlowLayoutPanel{Dock=DockStyle.Fill};start.Text=server?"Udostępnij interfejs":"Połącz z samochodem";start.Width=230;start.Height=38;start.BackColor=Color.FromArgb(30,104,203);start.ForeColor=Color.White;start.FlatStyle=FlatStyle.Flat;
   stop.Text=server?"Zakończ udostępnianie":"Rozłącz";stop.Width=200;stop.Height=38;
   recover.Text="Zwolnij USB po awarii";recover.AutoSize=true;recover.Click+=async delegate{await Recover();};
   start.Click+=async delegate{await StartSession();};stop.Click+=delegate{StopSession();};actions.Controls.Add(start);actions.Controls.Add(stop);actions.Controls.Add(recover);root.Controls.Add(actions,0,5);
   status.Dock=DockStyle.Fill;status.Padding=new Padding(10);status.BackColor=Color.FromArgb(225,236,250);status.Text="Przygotowanie…";root.Controls.Add(status,0,6);
   settings.Text="Jednorazowe przygotowanie USB";settings.Dock=DockStyle.Top;settings.Height=115;settings.Visible=false;
   var config=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=2,Padding=new Padding(8)};config.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));config.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,150));
   tool.Text=WindowsUsb.FindTool(server);tool.ReadOnly=true;tool.Dock=DockStyle.Fill;var browse=new Button{Text="Wskaż program…",Dock=DockStyle.Fill};browse.Click+=async delegate{await ChooseTool();};config.Controls.Add(tool,0,0);config.Controls.Add(browse,1,0);
   var download=new LinkLabel{Text=server?"Zainstaluj usbipd-win 5.3.0 (MSI x64)":"Zainstaluj usbip-win2 0.9.8.1 (x64)",AutoSize=true};download.LinkClicked+=delegate{Open(server?WindowsUsb.ServerDownload:WindowsUsb.ClientDownload);};
   config.Controls.Add(download,0,1);config.SetColumnSpan(download,2);settings.Controls.Add(config);root.Controls.Add(settings,0,7);
   var journal=new Panel{Dock=DockStyle.Fill};log.Dock=DockStyle.Fill;log.Multiline=true;log.ReadOnly=true;log.ScrollBars=ScrollBars.Both;log.WordWrap=false;log.Font=new Font("Consolas",9);log.Visible=false;journal.Controls.Add(log);root.Controls.Add(journal,0,8);
   var footer=new FlowLayoutPanel{Dock=DockStyle.Fill};advanced.Text="Ustawienia USB";advanced.AutoSize=true;advanced.CheckedChanged+=delegate{settings.Visible=advanced.Checked;};details.Text="Szczegóły";details.AutoSize=true;details.CheckedChanged+=delegate{log.Visible=details.Checked;};
   var help=new LinkLabel{Text="Instrukcja",AutoSize=true,Margin=new Padding(12,5,12,0)};help.LinkClicked+=delegate{string path=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"INSTRUKCJA.html");if(File.Exists(path))Open(path);else SetStatus("Instrukcja znajduje się w głównym folderze paczki.");};transfer.AutoSize=true;transfer.Padding=new Padding(10,4,0,0);
   footer.Controls.Add(advanced);footer.Controls.Add(details);footer.Controls.Add(help);footer.Controls.Add(transfer);root.Controls.Add(footer,0,9);
   mode.SelectedIndexChanged+=async delegate{if(!busy){UpdateControls();await RefreshEquipment();}};
   code.TextChanged+=delegate{if(!server&&!busy){try{var invite=Invitation.Parse(code.Text);mode.SelectedIndex=invite.Mode=="USB"?0:1;SetStatus("Kod gotowy. Tryb "+invite.Mode+" zostanie ustawiony automatycznie.");}catch(FormatException e){if(code.TextLength>0)SetStatus(e.Message);}UpdateControls();}};
   timer.Tick+=delegate{if(tunnel!=null)transfer.Text="TX "+Interlocked.Read(ref tunnel.Sent)/1024+" KB  •  RX "+Interlocked.Read(ref tunnel.Received)/1024+" KB";};timer.Start();
   Shown+=async delegate{await RefreshEquipment();};
   FormClosing+=delegate(object sender,FormClosingEventArgs e){if(busy||refreshing){closing=true;e.Cancel=true;StopSession();SetStatus("Kończenie sesji i zwalnianie interfejsu…");}else timer.Dispose();};
  }
  void SetStatus(string text){if(!IsDisposed)status.Text=text;}
  void Error(Exception error){string message=error.GetBaseException().Message;SetStatus(message);Log(message);}
  void Log(string message){
   if(IsDisposed||Disposing)return;
   if(InvokeRequired){try{BeginInvoke((Action)(()=>Log(message)));}catch(InvalidOperationException){}return;}
   if(log.TextLength>60000)log.Clear();log.AppendText(DateTime.Now.ToString("HH:mm:ss")+"  "+message+Environment.NewLine);
   if(message.StartsWith("OCZEKIWANIE",StringComparison.Ordinal)&&busy&&cancellation!=null&&!cancellation.IsCancellationRequested){code.Text=pendingCode;SetStatus("Gotowe. Przekaż kod diagnoście i pozostaw program otwarty.");UpdateControls();}
   if(server&&busy&&cancellation!=null&&!cancellation.IsCancellationRequested&&message.StartsWith("POŁĄCZONO",StringComparison.Ordinal))SetStatus("Diagnosta połączony. Interfejs jest udostępniany.");
  }
  void Open(string target){try{Process.Start(new ProcessStartInfo(target){UseShellExecute=true});}catch(Exception e){Error(e);}}
  UsbIpBackend NewBackend(){return new UsbIpBackend(new SystemCommandRunner(),server?tool.Text:"",server?"":tool.Text);}
  void UpdateControls(){
   bool idle=!busy&&!refreshing;
   start.Enabled=idle&&share==null&&attachment==null&&!File.Exists(Journal);stop.Enabled=busy;refresh.Enabled=idle;
   mode.Enabled=server&&idle;vpn.Enabled=server&&idle;equipment.Enabled=idle&&(server||!UsbMode);advanced.Enabled=idle;
   copy.Enabled=!server||busy&&code.TextLength>0;code.ReadOnly=server||busy;settings.Enabled=idle;
   recover.Visible=File.Exists(Journal)||share!=null&&!busy||attachment!=null&&!busy;recover.Enabled=idle;
   deviceLabel.Text=UsbMode?(server?"Interfejs USB":"USB z kodu"):(server?"Przewód ENET":"Karta TAP");
   equipment.Visible=server||!UsbMode;refresh.Visible=server||!UsbMode;
  }
  async Task RefreshEquipment(){
   if(busy||refreshing)return;refreshing=true;UpdateControls();
   try{
    string previous=(equipment.SelectedItem as UsbIpDevice)?.InstanceId??(equipment.SelectedItem as AdapterInfo)?.Id;
    var selected=vpn.SelectedItem as VpnAddress;vpn.Items.Clear();foreach(var item in WindowsUsb.VpnAddresses())vpn.Items.Add(item);
    vpn.SelectedIndex=-1;for(int i=0;i<vpn.Items.Count;i++)if(((VpnAddress)vpn.Items[i]).Address.Equals(selected?.Address))vpn.SelectedIndex=i;
    if(vpn.SelectedIndex<0&&vpn.Items.Count==1)vpn.SelectedIndex=0;
    equipment.Items.Clear();var engine=NewBackend();
    if(UsbMode){if(server){var devices=await Task.Run(()=>{engine.CheckTools(true);return engine.Devices();});foreach(var device in devices)equipment.Items.Add(device);
      var matches=devices.Where(d=>d.InstanceId==previous).ToList();if(matches.Count==0)matches=devices.Where(d=>(d.Description??"").IndexOf("Openport",StringComparison.OrdinalIgnoreCase)>=0||(d.Description??"").IndexOf("Tactrix",StringComparison.OrdinalIgnoreCase)>=0).ToList();
      if(matches.Count==1)equipment.SelectedItem=matches[0];else if(devices.Count==1)equipment.SelectedIndex=0;
     }else await Task.Run(()=>engine.CheckTools(false));
    }else{
     var adapters=AdapterInfo.List(!server);foreach(var adapter in adapters)equipment.Items.Add(adapter);
     equipment.SelectedIndex=-1;for(int i=0;i<equipment.Items.Count;i++)if(((AdapterInfo)equipment.Items[i]).Id==previous)equipment.SelectedIndex=i;
     if(equipment.SelectedIndex<0&&equipment.Items.Count==1)equipment.SelectedIndex=0;
    }
    SetStatus(vpn.Items.Count==0?"Uruchom RadminVPN i połącz oba komputery z tą samą siecią.":File.Exists(Journal)?"Pozostało USB z poprzedniej sesji. Kliknij Zwolnij USB po awarii.":"Gotowy. "+(server?"Wybierz interfejs i kliknij Udostępnij.":"Wklej kod z komputera przy samochodzie."));
   }catch(Exception e){Error(e);if(UsbMode)advanced.Checked=true;}
   finally{refreshing=false;UpdateControls();if(closing)Close();}
  }
  async Task ChooseTool(){
   using(var dialog=new OpenFileDialog{Title="Wskaż zainstalowany "+(server?"usbipd.exe":"usbip.exe"),Filter=server?"USB/IP Server|usbipd.exe":"USB/IP Client|usbip.exe",CheckFileExists=true}){
    if(dialog.ShowDialog()!=DialogResult.OK)return;refreshing=true;UpdateControls();
    try{string path=dialog.FileName;await Task.Run(()=>{var engine=new UsbIpBackend(new SystemCommandRunner(),path,path);engine.CheckTools(server);});WindowsUsb.RememberTool(server,path);tool.Text=path;}
    catch(Exception e){Error(e);}finally{refreshing=false;UpdateControls();}
    if(closing)Close();else await RefreshEquipment();
   }
  }
  static Task Blocking(Action action){return Task.Factory.StartNew(action,CancellationToken.None,TaskCreationOptions.LongRunning,TaskScheduler.Default);}
  void StopSession(){if(cancellation!=null)cancellation.Cancel();tunnel?.Dispose();SetStatus("Zwalnianie interfejsu…");}
  async Task StartSession(){
   if(busy||refreshing||share!=null||attachment!=null)return;
   busy=true;cancellation=new CancellationTokenSource();var token=cancellation.Token;UpdateControls();X509Certificate2 certificate=null;sessionTask=null;
   string failure=null;
   try{
    if(File.Exists(Journal))throw new IOException("Najpierw zwolnij USB po poprzedniej sesji.");
    if(WindowsUsb.VpnAddresses().Count==0)throw new IOException("Uruchom RadminVPN i dołącz do sieci klienta.");
    Invitation invite;var address=vpn.SelectedItem as VpnAddress;string toolPath=tool.Text;
    if(server){
     if(address==null)throw new IOException("Wybierz swój adres RadminVPN.");
     if(UsbMode&&!(equipment.SelectedItem is UsbIpDevice))throw new IOException("Podłącz Openport i wybierz go na liście USB.");
     invite=new Invitation{Host=address.Address.ToString(),Port=SessionPort,Pin=new string('A',64),Key=Wire.Secret(),Mode=UsbMode?"USB":"LAN",UsbBusId=UsbMode?((UsbIpDevice)equipment.SelectedItem).BusId:""};
    }else {invite=Invitation.Parse(code.Text);mode.SelectedIndex=invite.Mode=="USB"?0:1;}
    invite.Validate();var adapter=equipment.SelectedItem as AdapterInfo;
    if(invite.Mode=="LAN"){
     if(adapter==null)throw new IOException(server?"Wybierz kartę połączoną przewodem z autem.":"Wybierz wirtualną kartę TAP-Windows6.");
     if(server){var nic=NetworkInterface.GetAllNetworkInterfaces().SingleOrDefault(n=>n.Id==adapter.Id);if(nic==null||nic.GetIPProperties().GatewayAddresses.Count>0)throw new IOException("Wybierz dedykowaną kartę ENET bez bramy. Internet pozostaw na drugiej karcie.");}
    }
    SetStatus("Przygotowanie interfejsu…");
    if(invite.Mode=="USB"){
     backend=NewBackend();await Task.Run(()=>backend.CheckTools(server));token.ThrowIfCancellationRequested();
     if(server){
      if(File.Exists(Journal))throw new IOException("Najpierw zwolnij USB po poprzedniej sesji.");
      var selected=equipment.SelectedItem as UsbIpDevice;
      await Task.Run(()=>WindowsUsb.PrepareFirewall(address,SessionPort,toolPath));token.ThrowIfCancellationRequested();
      share=await Task.Run(()=>backend.Share(selected));
      if(share.Owned){Directory.CreateDirectory(Platform.DataDir);File.WriteAllText(Journal,share.Device.PersistedGuid);}
      await Task.Run(()=>WindowsUsb.ProbeExport(invite.UsbBusId));token.ThrowIfCancellationRequested();
     }
    }else if(server)await Task.Run(()=>WindowsUsb.PrepareLanFirewall(address,SessionPort));
    token.ThrowIfCancellationRequested();
    if(server){certificate=await Task.Run(()=>Platform.Certificate());token.ThrowIfCancellationRequested();invite.Pin=Wire.Pin(certificate.RawData);pendingCode=invite.Encode();code.Clear();}
    var current=new Tunnel(server,invite.Mode,Log,0,3240,server?address.Address:null);tunnel=current;var cert=certificate;
    sessionTask=Blocking(()=>current.Run(invite,cert,()=>server?(IEthernet)new PcapAdapter(adapter.Id):new TapAdapter(adapter.Id)));
    if(!server){
     var deadline=DateTime.UtcNow.AddSeconds(30);SetStatus("Łączenie z komputerem przy samochodzie…");
     while(!current.Connected){token.ThrowIfCancellationRequested();if(sessionTask.IsCompleted){await sessionTask;throw new IOException("Nie utworzono połączenia.");}if(DateTime.UtcNow>deadline)throw new IOException("Przekroczono czas zestawiania połączenia.");await Task.Delay(50,token);}
     if(invite.Mode=="USB"){
      Directory.CreateDirectory(Platform.DataDir);File.WriteAllText(Journal,current.UsbPort+"|"+invite.UsbBusId);
      SetStatus("Podłączanie USB do Windows…");attachment=await Task.Run(()=>backend.Attach(current.UsbPort,invite.UsbBusId));token.ThrowIfCancellationRequested();
      SetStatus("USB podłączone do Windows. Sprawdź Openport w Xentry PassThru.");
     }else SetStatus("Tunel ENET połączony. Sprawdź adresację TAP i wykrywanie auta.");
    }
    if(!server&&attachment!=null){
     while(!sessionTask.IsCompleted){
      await Task.WhenAny(sessionTask,Task.Delay(2000,token));token.ThrowIfCancellationRequested();
      if(!sessionTask.IsCompleted&&!await Task.Run(()=>attachment.Present()))throw new IOException("Utracono interfejs USB. Sprawdź przewód i rozpocznij nową sesję.");
     }
    }
    await sessionTask;
   }catch(Exception e){if(!token.IsCancellationRequested){failure=e.GetBaseException().Message;Log(failure);}}
   finally{
    tunnel?.Dispose();if(sessionTask!=null)try{await sessionTask;}catch(Exception){}
    bool clean=await Cleanup();certificate?.Dispose();tunnel=null;pendingCode=null;if(server)code.Clear();cancellation.Dispose();cancellation=null;busy=false;
    UpdateControls();SetStatus(!clean?"Nie udało się zwolnić USB. Użyj przycisku zwalniania i sprawdź szczegóły.":failure??"Sesja zakończona. Interfejs został zwolniony.");if(closing)Close();
   }
  }
  async Task<bool> Cleanup(){
   bool clean=true;
   if(attachment!=null)try{await Task.Run(()=>attachment.Dispose());attachment=null;}catch(Exception e){clean=false;Log(e.GetBaseException().Message);}
   if(share!=null)try{await Task.Run(()=>share.Dispose());share=null;if(File.Exists(Journal))File.Delete(Journal);}catch(Exception e){clean=false;Log(e.GetBaseException().Message);}
   if(!server&&attachment==null&&File.Exists(Journal))try{await ReleaseClientJournal();}catch(Exception e){clean=false;Log(e.GetBaseException().Message);}
   return clean;
  }
  async Task ReleaseClientJournal(){
   string[] fields=File.ReadAllText(Journal).Trim().Split('|');int port;
   if(fields.Length!=2||!int.TryParse(fields[0],out port)||port<1024||port>65535||!UsbIpBackend.ValidBusId(fields[1]))throw new IOException("Uszkodzony zapis poprzedniej sesji USB. Sprawdź instrukcję odzyskiwania.");
   var engine=NewBackend();await Task.Run(()=>{engine.CheckTools(false);engine.ReleaseEndpoint(port,fields[1]);});File.Delete(Journal);
  }
  async Task Recover(){
   if(busy||refreshing)return;refreshing=true;UpdateControls();
   try{
    if(!await Cleanup())throw new IOException("Nie udało się zwolnić interfejsu. Sprawdź szczegóły.");
    if(server&&File.Exists(Journal)){string guid=File.ReadAllText(Journal).Trim();var engine=NewBackend();await Task.Run(()=>{engine.CheckTools(true);engine.Unshare(guid);});File.Delete(Journal);}
    SetStatus("USB zwolnione. Możesz rozpocząć nową sesję.");
   }catch(Exception e){Error(e);}finally{refreshing=false;UpdateControls();if(closing)Close();}
  }
 }
 static class Program {
  [STAThread] static void Main(){
   Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
#if Server
   const string role="Server";
#else
   const string role="Client";
#endif
   bool created;using(var mutex=new Mutex(true,"Local\\AutoTunel-MB-"+role,out created)){
    if(!created){MessageBox.Show("Ten program jest już uruchomiony.","AutoTunel MB");return;}
    Application.Run(new MainForm());
   }
  }
 }
}
