using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;

namespace AutoTunel {
 public sealed class SystemCommandRunner:ICommandRunner {
  public static string QuoteArgument(string value){
   if(value==null||value.IndexOf('\0')>=0)throw new ArgumentException("Nieprawidłowy argument.");
   var s=new StringBuilder("\"");int slashes=0;
   foreach(char c in value){if(c=='\\'){slashes++;continue;}s.Append('\\',c=='"'?slashes*2+1:slashes);s.Append(c);slashes=0;}
   s.Append('\\',slashes*2);return s.Append('"').ToString();
  }
  public string Run(string executable,string[] arguments,int timeout){
   if(string.IsNullOrWhiteSpace(executable)||!File.Exists(executable))throw new FileNotFoundException("Brak narzędzia USB/IP. Zainstaluj obsługę USB lub wskaż program w ustawieniach.");
   using(var process=Process.Start(new ProcessStartInfo(executable,string.Join(" ",arguments.Select(QuoteArgument))){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true,StandardOutputEncoding=Encoding.UTF8,StandardErrorEncoding=Encoding.UTF8})){
    var output=process.StandardOutput.ReadToEndAsync();var error=process.StandardError.ReadToEndAsync();
    if(!process.WaitForExit(timeout)){try{process.Kill();process.WaitForExit(3000);}catch(InvalidOperationException){}throw new IOException("Narzędzie USB/IP nie odpowiedziało w wyznaczonym czasie.");}
    string text=output.GetAwaiter().GetResult(),detail=error.GetAwaiter().GetResult();
    if(process.ExitCode!=0)throw new IOException("USB/IP: "+(string.IsNullOrWhiteSpace(detail)?text:detail).Trim());
    return text.Trim();
   }
  }
 }
 public sealed class VpnAddress {
  public string Adapter;public IPAddress Address;
  public override string ToString(){return Adapter+" — "+Address;}
 }
 public static class WindowsUsb {
  public const string ServerDownload="https://github.com/dorssel/usbipd-win/releases/tag/v5.3.0";
  public const string ClientDownload="https://github.com/vadimgrn/usbip-win2/releases/tag/v.0.9.8.1";
  public static List<VpnAddress> VpnAddresses(){
   var list=new List<VpnAddress>();
   foreach(var nic in NetworkInterface.GetAllNetworkInterfaces()){
    if(nic.OperationalStatus!=OperationalStatus.Up||(nic.Name+" "+nic.Description).IndexOf("Radmin",StringComparison.OrdinalIgnoreCase)<0)continue;
    foreach(var address in nic.GetIPProperties().UnicastAddresses)if(address.Address.AddressFamily==AddressFamily.InterNetwork&&!IPAddress.IsLoopback(address.Address))list.Add(new VpnAddress{Adapter=nic.Name,Address=address.Address});
   }
   return list;
  }
  public static string FindTool(bool server){
   string saved=Path.Combine(Platform.DataDir,server?"usbipd-path.txt":"usbip-path.txt");
   if(File.Exists(saved)){string file=File.ReadAllText(saved).Trim();if(File.Exists(file)&&Path.GetFileName(file).Equals(server?"usbipd.exe":"usbip.exe",StringComparison.OrdinalIgnoreCase))return file;}
   string root=Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
   return Path.Combine(root,server?"usbipd-win":"USBip",server?"usbipd.exe":"usbip.exe");
  }
  public static void RememberTool(bool server,string path){Directory.CreateDirectory(Platform.DataDir);File.WriteAllText(Path.Combine(Platform.DataDir,server?"usbipd-path.txt":"usbip-path.txt"),path);}
  static string Ps(string value){return "'"+value.Replace("'","''")+"'";}
  public static void PrepareFirewall(VpnAddress vpn,int port,string usbipd){
   // The upstream server listens on every interface. Block direct, unauthenticated
   // USB/IP access; AutoTunel alone forwards authenticated imports over loopback.
   string script="$ErrorActionPreference='Stop'; "+
    "if (@(Get-NetFirewallProfile -PolicyStore ActiveStore | Where-Object { $_.Enabled -ne 'True' }).Count -gt 0) { throw 'Włącz Zaporę Windows dla wszystkich profili przed udostępnianiem USB.' }; "+
    "$usbRule=@{Name='AutoTunel-USBIP-LocalOnly';Direction='Inbound';Action='Block';Program="+Ps(usbipd)+";Protocol='TCP';LocalPort='3240';RemoteAddress=@('0.0.0.0-126.255.255.255','128.0.0.0-255.255.255.255','::/0');Profile='Any';Enabled='True'}; "+
    "if (Get-NetFirewallRule -Name 'AutoTunel-USBIP-LocalOnly' -ErrorAction SilentlyContinue) { Set-NetFirewallRule @usbRule | Out-Null } else { New-NetFirewallRule @usbRule -DisplayName 'AutoTunel: USB/IP tylko lokalnie' | Out-Null }; "+
    SessionFirewall(vpn,port)+
    " $block=Get-NetFirewallRule -Name 'AutoTunel-USBIP-LocalOnly' -PolicyStore ActiveStore; if ($block.Enabled -ne 'True' -or $block.Action -ne 'Block' -or $block.EnforcementStatus -ne 'Full') { throw 'Polityka Windows nie potwierdziła aktywnej blokady bezpośredniego USB/IP. Sprawdź zaporę i zasady administratora.' }; Write-Output 'OK';";
   if(Platform.Powershell(script)!="OK")throw new IOException("Nie potwierdzono ustawień zapory USB/IP.");
  }
  static string SessionFirewall(VpnAddress vpn,int port){
   if(vpn==null||vpn.Address.AddressFamily!=AddressFamily.InterNetwork||port<1024||port>65535)throw new ArgumentException("Wybierz adres RadminVPN.");
   return "Get-NetFirewallRule -Name 'AutoTunel-Session' -ErrorAction SilentlyContinue | Remove-NetFirewallRule; "+
    "New-NetFirewallRule -Name 'AutoTunel-Session' -DisplayName 'AutoTunel: sesja RadminVPN' -Direction Inbound -Action Allow -Program "+Ps(Process.GetCurrentProcess().MainModule.FileName)+" -Protocol TCP -LocalPort "+port+" -InterfaceAlias "+Ps(vpn.Adapter)+" -LocalAddress "+Ps(vpn.Address.ToString())+" -Profile Any | Out-Null;";
  }
  public static void PrepareLanFirewall(VpnAddress vpn,int port){Platform.Powershell("$ErrorActionPreference='Stop'; "+SessionFirewall(vpn,port));}
  public static void ProbeExport(string busId){
   using(var tcp=new TcpClient()){
    if(!tcp.ConnectAsync(IPAddress.Loopback,3240).Wait(2000))throw new IOException("Usługa USB/IP nie odpowiada. Sprawdź usługę usbipd.");
    tcp.ReceiveTimeout=3000;tcp.SendTimeout=3000;UsbIpProbe.RequireExport(tcp.GetStream(),busId);
   }
  }
 }
}
