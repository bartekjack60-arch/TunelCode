$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
 foreach ($role in @('Client','Server')) {
  & dotnet build AutoTunel.csproj -c Release "-p:Role=$role" -o "dist/$role"
  if ($LASTEXITCODE -ne 0) { throw "Kompilacja $role nie powiodła się." }
 }
 & dotnet run --project tests/Tests.csproj -c Release
 if ($LASTEXITCODE -ne 0) { throw 'Testy nie powiodły się.' }
} finally { Pop-Location }
