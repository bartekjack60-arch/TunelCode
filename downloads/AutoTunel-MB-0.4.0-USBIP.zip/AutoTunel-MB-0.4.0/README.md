# AutoTunel MB 0.4 — USB/IP przez RadminVPN

Prototyp Windows do zdalnego korzystania z interfejsu przy samochodzie.
Pierwszy cel: **Xentry PassThru + Openport 2.0 + Windows 10/11 x64**.
Nie korzysta z VirtualHere. Obsługę fizycznego i wirtualnego USB zapewniają
oddzielnie instalowane, otwarte komponenty USB/IP; aplikacja steruje sesją.

| Komputer | Program | Zadanie |
|---|---|---|
| U klienta przy samochodzie | `Server/AutoTunel-Server.exe` | Udostępnia wybrany przewód USB lub ENET |
| U Ciebie, przy diagnostyce | `Client/AutoTunel-Client.exe` | Podłącza zdalny interfejs do Twojego komputera |

## Pierwsze uruchomienie USB

1. Rozpakuj ZIP na obu komputerach; zostaw `.exe.config` przy EXE.
2. Połącz komputery przez RadminVPN. Uruchom Server przy samochodzie,
   Client u diagnosty. Programy wymagają uprawnień administratora.
3. W ustawieniach USB są linki do jednorazowej instalacji:
   - Server: [usbipd-win 5.3.0](https://github.com/dorssel/usbipd-win/releases/tag/v5.3.0), instalator x64.
   - Client: [usbip-win2 0.9.8.1](https://github.com/vadimgrn/usbip-win2/releases/tag/v.0.9.8.1), podpisany instalator x64.
   Sterowniki tych projektów nie są dołączone do tej paczki.
4. U diagnosty zainstaluj właściwy sterownik swojego Openporta. Zwolnij go
   w VirtualHere i innych aplikacjach przed rozpoczęciem próby.
5. W Server wybierz USB i Openport, kliknij **Udostępnij interfejs**.
   Pojedynczy rozpoznany Openport i adres RadminVPN są wybierane automatycznie.
   Jeśli jest kilka możliwości, wybierz właściwą.
6. Gdy pojawi się kod, przekaż go prywatnie diagnoście.
7. W Client kliknij **Wklej kod**, następnie **Połącz z samochodem**.
   Tryb USB i urządzenie wynikają z kodu; podłączenie wykonuje się automatycznie.
8. Sprawdź stan urządzenia w Windows, potem wykrycie i odczyt w Xentry.
   Po zakończeniu pracy kliknij **Rozłącz**.

Szczegółowy przebieg próby i oczekiwane wyniki: [WINDOWS-TEST.md](WINDOWS-TEST.md).
Oprogramowanie wymaga .NET Framework 4.8; użytkownik gotowych EXE nie potrzebuje
.NET SDK, Pythona ani WSL. Własne EXE prototypu nie mają podpisu wydawcy.

## Co robi aplikacja

- Rozpoznaje aktywną kartę RadminVPN i na niej uruchamia sesję Server.
- Odczytuje rzeczywiste urządzenia przez `usbipd state`, sprawdza wersje narzędzi
  i obecność sterownika klienta.
- Udostępnia wybrane USB, potwierdza eksport odpowiedzią USB/IP i generuje kod
  dopiero po uruchomieniu nasłuchu.
- Kod AMB4 zawiera adres, tryb, identyfikator USB, pin certyfikatu i sekret
  sesji. Nie publikuj kodu. Starsze wersje aplikacji nie są zgodne z AMB4.
- Przesyła dane USB/IP przez własną sesję TLS 1.2. Kontrola importu blokuje
  żądania dostępu do urządzenia innego niż wybrane oraz listowanie innych USB.
- Wywołuje klienta USB/IP z `--once`, potwierdza lokalny port urządzenia
  i sprawdza jego obecność podczas sesji. Nie ponawia automatycznie podłączenia.
- Zwalnia własne podłączenie i własne udostępnienie; zachowuje stan urządzeń
  udostępnionych wcześniej przez użytkownika.
- Udostępnia przycisk odzyskiwania po awarii; zapisuje lokalnie identyfikatory
  potrzebne do zwolnienia własnego USB, bez kluczy i kodów sesji.

## Zapora i sieć

Sesja aplikacji używa TCP 24832 na wybranej karcie RadminVPN.
Nie wymaga publicznego adresu ani przekierowania portu na routerze.
USB/IP używa lokalnego portu 3240 przy samochodzie; klient sterownika łączy
się z losowym portem loopback u diagnosty. Te połączenia przenosi tunel TLS.

Server tworzy dwie własne reguły Zapory Windows. Jedna dopuszcza sesję na karcie
RadminVPN, druga blokuje bezpośredni dostęp sieciowy do portu 3240 procesu
usbipd. Wszystkie profile Zapory Windows muszą być włączone. Reguła blokowania
pozostaje po zamknięciu aplikacji i może ograniczać inne zastosowania usbipd,
w tym WSL. Po zakończeniu używania prototypu można usunąć wyłącznie te reguły
przez `KONFIGURUJ_ZAPORE.ps1 -Remove`, jako administrator, przy zamkniętym Server.

## ENET

Zachowano tunel Ethernet L2: dedykowana karta i Npcap x64 przy samochodzie,
TAP-Windows6 (`tap0901`) u diagnosty. Po stronie auta aplikacja odrzuca kartę
z bramą, żeby nie przejąć połączenia internetowego. Client rozpoznaje tryb z kodu.

Ramki Ethernet, ARP i broadcast przechodzą bez ręcznego mostkowania. Adresacja
TAP wymaga jeszcze przygotowania dla danej sieci auta; aplikacja nie zmienia
jej automatycznie. Ten tryb nie zamienia ENET w J2534. Wymaga programu
obsługującego odpowiednią komunikację Ethernet/DoIP.

## Stan weryfikacji

W Linux sprawdzono kompilację obu EXE dla .NET Framework 4.8 x64 oraz testy
transportu, USB/IP, obsługi narzędzi i zwalniania zasobów. Raport: `TESTY.txt`.
Testy CLI używają kontrolowanych odpowiedzi narzędzi, a transportu — prawdziwych
lokalnych TCP/TLS z symulowanymi urządzeniami. Nie jest to test fizycznego USB.

**Nie uruchomiono GUI, sterowników USB/IP ani Xentry na Windows.** Zgodność
Openporta (w tym klona), SM2/SM3 Pro, Launch, VCX SE, DTS Monaco i Vediamo
pozostaje niepotwierdzona. Programowanie ECU wymaga osobnej oceny po próbach
sprzętowych; ten prototyp służy najpierw do identyfikacji i odczytu.

## Kod

Źródła: `source/src`. Budowanie: `source/BUILD.ps1` na Windows lub
`tools/build.sh` na Linux z .NET SDK 8. Testy to program konsolowy,
nie projekt uruchamiany przez `dotnet test`. Szczegóły: `DEVELOPMENT.md`.
