# Rozwój AutoTunel MB 0.7

Cel: jeden EXE zawiera pakiety potrzebne do obsługi USB/IP. Windows instaluje
komponenty automatycznie z zasobów EXE, z uprawnieniami administratora.
Protokół AMB4, TLS i zasady własności urządzeń pozostają zgodne z 0.5.

## Budowanie

Wymagane .NET SDK 8 i reference assemblies .NET Framework 4.8 z NuGet
(Microsoft.NETFramework.ReferenceAssemblies 1.0.3).
Windows: `powershell -File source/BUILD.ps1`. Linux: `bash tools/build.sh`.
W bieżącym środowisku:

```bash
export DOTNET_ROOT=/workspace/.tools/dotnet-8
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_CLI_HOME=/workspace/.cache/dotnet-cli
export NUGET_PACKAGES=/workspace/.cache/nuget/packages
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
cd /workspace/TunelCode
bash tools/build.sh
```

Wynik: `source/dist/AutoTunel/AutoTunel.exe`, net48 x64, bez DLL/config obok EXE.
Pomoc, licencje i oba instalatory są zasobami EXE. Pełny ZIP zawiera `vendor/usb`.
Skrypty sprawdzają SHA-256 pakietów przed kompilacją. Do przywrócenia brakujących
pakietów na komputerze dewelopera: `python3 tools/fetch-usb.py`.
Aplikacja nie wykonuje pobierania.

Testy: `dotnet run --project source/tests/Tests.csproj -c Release`.
Wybrany zakres: dopisz `-- "USB setup"`. Brak dopasowań jest błędem.
Weryfikacja rzeczywistego EXE:

```bash
dotnet run --project source/tests/Tests.csproj -c Release -- \
  --verify-bundle "$PWD/source/dist/AutoTunel/AutoTunel.exe"
```

Sprawdzane są wersja, SHA-256 obu osadzonych pakietów, aktualność instrukcji,
obecność licencji i brak zewnętrznych DLL/config. Tryb ten nie instaluje sterowników.

## Przygotowanie USB

- `UsbSetup.cs`: polityka przygotowania, metadane, integralność, kody instalatora,
  anulowanie przed instalacją i wymagany restart.
- `WindowsUsbSetup.cs`: globalna blokada, chronione pliki robocze, instalatory,
  wykrywanie programów i usługi.
- `MainForm.cs`: serwer jest przygotowywany przed listą USB, klient przed
  połączeniem USB. Przycisk „Przygotuj USB” pozwala przygotować je wcześniej.
- `vendor/usb/packages.json`: źródło nazw plików, zasobów i sum SHA-256.

Wbudowano niezmodyfikowane oficjalne usbipd-win 5.3.0 x64 MSI i usbip-win2
0.9.8.1 x64 EXE. SHA-256 są zgodne z `digest` oficjalnych wydań GitHub.
Nie modyfikujemy sterowników ani nie włączamy trybu testowego Windows.

MSI: systemowy msiexec, `/qn /norestart REBOOT=ReallySuppress`,
`ADDLOCAL=Server,Drivers`, pełny dziennik. Klient: `/SP- /VERYSILENT
/SUPPRESSMSGBOXES /NORESTART /RESTARTEXITCODE=3010`, `main,client`, zadanie
`vcredist`. Nie wybieramy GUI, SDK ani PDB; runtime Visual C++ jest już
w instalatorze. Wyłączamy automatyczne zamykanie i restart innych aplikacji.

Plik jest wypisywany do nowego `%ProgramData%\AutoTunel-MB-USB-<losowy ID>`
z ACL tylko dla Administratorów i SYSTEM. SHA-256 jest sprawdzany przed
uruchomieniem. Uszkodzony plik jest usuwany. Globalny mutex serializuje
przygotowanie. Po zakończeniu instalatora kopia robocza jest usuwana;
`install.log` pozostaje. Ścieżkę zapisuje dziennik aplikacji.

Przed instalacją zapisujemy w HKLM (widok 64-bit)
`SOFTWARE\AutoTunel-MB\UsbSetup` wartości `ServerRestart` / `ClientRestart`.
Zawierają czas ostatniego startu Windows z WMI `LastBootUpTime`. Znacznik
pozostaje po błędzie lub awarii aplikacji; ta sama sesja Windows blokuje
kolejne przygotowanie. Nowy start usuwa znacznik, następnie ponownie
sprawdzana jest gotowość. Po sukcesie serwera bez restartu znacznik usuwamy
dopiero po potwierdzeniu narzędzia i usługi.

3010 i 1641 oznaczają restart. Klient wymaga go także przy kodzie 0, bo jego
przypięty `setup.iss` deklaruje `AlwaysRestart=yes`. AutoTunel nigdy nie
wywołuje restartu. Po rozpoczęciu instalacji nie zabijamy instalatora przy
anulowaniu ani zamykaniu okna; czekamy do 15 minut. Po przekroczeniu limitu
instalator może nadal pracować, a znacznik blokuje kolejne przygotowanie.

Zgodna działająca instalacja jest używana bez reinstalacji. Istniejący plik
narzędzia o niezgodnej wersji lub niesprawny sterownik powoduje błąd.
Nie uruchamiamy automatycznej aktualizacji mogącej przerwać inne sesje USB.
Ustawienia obu ról i dzienniki odzyskiwania z 0.4/0.5 są zachowane.

## Źródła kontraktów

- usbipd-win 5.3.0: `Installer/Product.wxs`, `Installer/Server.wxs`, `Drivers/README.md`:
  https://github.com/dorssel/usbipd-win/tree/v5.3.0
- usbip-win2 0.9.8.1: `userspace/innosetup/setup.iss`:
  https://github.com/vadimgrn/usbip-win2/blob/v.0.9.8.1/userspace/innosetup/setup.iss
- Inno Setup: https://jrsoftware.org/ishelp/topic_setupcmdline.htm
- Windows Installer: https://learn.microsoft.com/en-us/windows/win32/msi/standard-installer-command-line-options

Źródła obu komponentów są w `vendor/sources`, licencje i przekazana oferta
źródeł sterowników VirtualBox w `vendor/licenses`. Standardowa reguła zapory
usbipd jest częścią niezmodyfikowanego MSI. AutoTunel nie zmienia stanu zapory.

## Pakowanie i zakres weryfikacji

Po budowaniu odśwież `TESTY.txt`, następnie:

```bash
python3 tools/package.py --output /ścieżka/AutoTunel-MB-0.7.0.zip
```

ZIP zawiera jeden gotowy EXE, źródła, pakiety vendor, licencje i dokumentację.
`bin`, `obj`, `dist` i cache są pomijane. Skrypt tworzy manifest SHA-256 i sprawdza ZIP.
Sam EXE wystarcza do użycia na Windows z .NET Framework 4.8.

Testy Linux używają lokalnego TCP/TLS i kontrolowanych odpowiedzi CLI. Nowe
testy przygotowania używają atrap operacji systemowych. Nie potwierdzają
instalatorów, WMI, PnP, restartu ani GUI Windows. Próba: `WINDOWS-TEST.md`.

## Interfejs i ikona 0.7

Interfejs korzysta wyłącznie z WinForms/GDI+ oraz systemowej czcionki Segoe UI.
Grafitowy motyw i własne kontrolki są w source/src/Ui.cs. Nie wymagają bibliotek
UI ani plików obok EXE. Ikona source/AutoTunel.ico ma rozmiary 16, 24, 32, 48,
64, 128 i 256 pikseli i trafia do natywnych zasobów Windows EXE. Ten sam plik
jest zasobem zarządzanym AutoTunel.Brand.ico dla okien, a logo
source/AutoTunel.png jest zasobem AutoTunel.Brand.png interfejsu.

Natywną ikonę i format EXE sprawdza:

```bash
python3 tools/verify-icon.py source/dist/AutoTunel/AutoTunel.exe source/AutoTunel.ico
```

Weryfikator porównuje każdą klatkę ICO z RT_GROUP_ICON/RT_ICON wewnątrz PE
i sprawdza AMD64, PE32+ oraz podsystem Windows GUI.
