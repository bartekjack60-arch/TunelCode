# AutoTunel MB 0.8 — naprawa instalacji USB

Wersja 0.8 poprawia obsługę błędów instalacji i niekompletnej obsługi USB.
Dla komputera **Przy samochodzie** pakiet usbipd-win 5.3.0 obsługuje Windows
10 1809/build 17763, w tym LTSC 2019. Rola **Diagnosta** wymaga nadal
Windows 10 1903/build 18362 lub nowszego. Program sprawdza to przed instalacją.

Po problemie w wersji 0.7: zamknij poprzedni program, uruchom nowy EXE, wybierz
**Przy samochodzie → Ustawienia USB → Napraw USB**. Naprawa jest dostępna po
zakończeniu sesji i zwolnieniu własnych urządzeń. Jeżeli pozostał zapis
wymaganego restartu z poprzedniej wersji, uruchom ponownie Windows.

Znana starsza zarejestrowana instalacja usbipd może zostać zaktualizowana do
wbudowanej wersji podczas jawnie wybranej naprawy. Zgodna wersja jest naprawiana
przez Windows Installer. Program odmawia tej operacji przy aktywnych sesjach
USB, maszynach VirtualBox, własnym dzienniku do odzyskania, nowszej albo
nierozpoznanej instalacji. Przy starszej wersji lub brakującym narzędziu
i działającej usłudze poprosi o zakończenie sesji oraz zatrzymanie
USBIP Device Host w systemowych Usługach Windows. Program nie wykonuje
masowego odłączania urządzeń samodzielnie.

**Diagnostyka USB** w dolnym pasku otwiera zachowane wyniki w
`%LOCALAPPDATA%\AutoTunel-MB\diagnostics`. Raport zawiera wykryty Windows,
architekturę, wersję USB/IP, kod zakończenia oraz dzienniki MSI i SetupAPI.
Błędy instalatora i jego uruchomienia nie są już zamieniane w fikcyjne żądanie
restartu. Prawdziwy wymagany restart oraz niepotwierdzona pracująca instalacja
nadal blokują kolejną instalację.

Nowa wersja ma spójny grafitowy interfejs, turkusowe akcenty, czytelniejszy wybór
roli i nową ikonę aplikacji. Ikona, pomoc i pakiety USB są zapisane w EXE.

Ten sam **AutoTunel.exe** działa na obu komputerach. Obsługa USB jest wbudowana:
AutoTunel sam przygotowuje narzędzia, usługę i sterowniki z pakietów zapisanych
wewnątrz EXE. Nie trzeba osobno pobierać instalatorów USB/IP ani wskazywać
ich programów. Przygotowanie USB nie pobiera pakietów z Internetu.

1. Skopiuj `AutoTunel.exe` na oba komputery Windows 10/11 x64 (przy samochodzie: od 1809; diagnosta: od 1903)
   z .NET Framework 4.8.
2. Połącz komputery przez RadminVPN. Uruchom AutoTunel i zaakceptuj uprawnienia
   administratora wymagane do obsługi sterowników.
3. Przy samochodzie wybierz **Przy samochodzie**. Program automatycznie
   przygotuje USB i pokaże dostępne urządzenia.
4. U diagnosty wybierz **Diagnosta**, wklej kod i kliknij **Połącz z samochodem**.
   Obsługa USB zostanie przygotowana automatycznie przed połączeniem.
5. Jeśli pojawi się komunikat o restarcie, wybierz w Windows **Uruchom ponownie**
   i otwórz ponownie AutoTunel. Komponent klienta wymaga tego po pierwszej
   instalacji. AutoTunel nie restartuje komputera samodzielnie.
6. Wybierz Openport przy samochodzie, kliknij **Udostępnij interfejs**, przekaż
   kod diagnoście i połącz się. Po zakończeniu pracy kliknij **Rozłącz**.

Przygotowanie można wykonać wcześniej: **Ustawienia USB → Przygotuj USB**.
Kolejne uruchomienia korzystają z zainstalowanej obsługi. Działające instalacje
usbipd-win 5.3.0 i usbip-win2 0.9.8.1 z wcześniejszej wersji są zachowywane.
Inne lub niesprawne istniejące instalacje wymagają osobnego sprawdzenia;
AutoTunel zgłasza przyczynę i wymaganą wersję.

Windows nadal instaluje sterownik w systemie — odbywa się to automatycznie
z EXE. Do uruchomienia wystarcza ten plik; pomoc i licencje są wbudowane.
Nie są potrzebne `.exe.config`, Python, WSL ani .NET SDK.

Wymagane są nadal RadminVPN, sterownik posiadanego interfejsu, np. Openporta,
oraz program diagnostyczny. Zmiana obejmuje obsługę USB/IP. Tryb ENET nadal
wymaga Npcap przy samochodzie i TAP-Windows6 u diagnosty.

Sesja używa TCP 24832 na wybranej karcie RadminVPN. USB/IP używa TCP 3240.
Oficjalny instalator usbipd-win tworzy standardową regułę zapory; AutoTunel
nie włącza ani nie wyłącza Zapory Windows. Przy wyłączonej zaporze bezpośredni
port 3240 jest dostępny z sieci i nie chroni go kod AutoTunel. Używaj zaufanej sieci.

Kompilację, testy logiki i transportu oraz zawartość EXE sprawdzono w Linux.
Instalacja sterowników, restart, GUI i fizyczny Openport/Xentry wymagają próby
na Windows według [WINDOWS-TEST.md](WINDOWS-TEST.md). Raport: [TESTY.txt](TESTY.txt).
EXE prototypu nie ma podpisu wydawcy AutoTunel.

Źródła aplikacji: `source/src`. Źródła komponentów i licencje: `vendor/sources`
i `vendor/licenses`. Budowanie: [DEVELOPMENT.md](DEVELOPMENT.md).
